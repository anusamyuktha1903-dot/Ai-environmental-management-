# EcoSmart AI - Project Documentation

**Title:** AI-Centered Environmental Management System
**Project name:** EcoSmart AI
**Stack:** React.js (Vite) + Bootstrap 5 + Chart.js, Python Flask, SQLite, Claude API (Anthropic)

---

## 1. Abstract

EcoSmart AI is a web-based environmental management platform. It lets citizens monitor air quality, report water
pollution, manage waste, report environmental problems with photos, and talk to an AI assistant. Administrators
review reports, answer complaints and monitor pollution statistics. Artificial intelligence (the Claude API)
analyses problem descriptions, generates reports, answers environmental questions and produces personalised
recommendations. When no API key is available, a built-in demo mode keeps every feature usable.

## 2. Objectives

1. Provide one place to monitor environmental conditions (air, water, waste).
2. Help users identify environmental problems from plain-language descriptions using AI.
3. Encourage proper waste segregation and recycling.
4. Give administrators tools to review reports, manage complaints and view pollution statistics.
5. Offer personalised AI recommendations to reduce pollution and save water and energy.

## 3. System architecture

```
 Browser (React SPA, Bootstrap, Chart.js)
        |  HTTP + JSON  (Authorization: Bearer <token>)
        v
 Vite dev server  --proxy /api, /uploads-->  Flask REST API (port 5000)
                                                |            |
                                                |            +--> services/ai_service.py --> Claude API (or Demo mode)
                                                v
                                          SQLite (database/ecosmart.db)  +  backend/uploads/ (images)
```

* **Frontend** - single-page application. `AuthContext` stores the logged-in user; `api.js` attaches the token to
  every request. Sidebar layout for logged-in users, navbar layout for public pages.
* **Backend** - Flask blueprints (one per feature). Decorators `login_required` / `admin_required` protect routes.
* **AI service** - `backend/services/ai_service.py` is the **only** file that talks to Claude. The key is read from
  the `ANTHROPIC_API_KEY` environment variable; the frontend never sees it. If the key is missing or a call fails,
  the same functions return predefined environmental knowledge (demo mode) and the response is flagged `demo: true`.
* **Database** - SQLite, created and seeded automatically by `database.py`.

## 4. Modules

| # | Module | Frontend page | Backend route file |
|---|---|---|---|
| 1 | Admin dashboard | AdminDashboard, AdminUsers, AdminComplaints | routes/admin.py |
| 2 | AI environmental analysis | AIAnalysis | routes/ai.py (`/analyze`) |
| 3 | Air quality monitoring | AirQuality | routes/air.py |
| 4 | Water quality management | Water | routes/water.py |
| 5 | Waste management | Waste | routes/waste.py |
| 6 | Smart environmental reporting | Reports | routes/reports.py |
| 7 | AI chatbot | Chatbot | routes/ai.py (`/chat`) |
| 8 | Environmental statistics | Statistics | routes/stats.py |
| 9 | AI recommendation system | Recommendations | routes/ai.py (`/recommendations`) |
| 10 | User management | Register, Login, Profile, Complaints | routes/auth.py, routes/complaints.py |

Additional public pages: Home, About Us, Contact.

## 5. Database design (SQLite)

| Table | Purpose | Main columns |
|---|---|---|
| `users` | Registered users | id, name, email (unique), password_hash, phone, city, created_at |
| `admin` | Administrator accounts | id, name, email (unique), password_hash, created_at |
| `environmental_reports` | Problems reported by users | id, user_id -> users, title, category, description, location, image_path, status (Pending / In Progress / Resolved / Rejected), admin_remarks, created_at, updated_at |
| `air_quality_data` | Sensor / demo air readings | id, city, aqi, pm25, pm10, no2, so2, co, recorded_at |
| `water_quality_reports` | Water test submissions | id, user_id, location, source_type, ph, turbidity, tds, dissolved_oxygen, description, issues_detected, status, created_at |
| `waste_management` | Waste collection reports | id, user_id, waste_type, quantity_kg, location, notes, status (Reported / Scheduled / Collected), created_at |
| `chat_history` | Chatbot conversation | id, user_id, role (user/assistant), message, created_at |
| `ai_recommendations` | Stored AI analyses and recommendations | id, user_id, kind, input_text, content, created_at |
| `complaints` | User complaints | id, user_id, subject, message, status (Open / In Progress / Resolved / Closed), admin_response, created_at |
| `contact_messages` | Contact form messages | id, name, email, message, created_at |
| `activity_log` | Admin "environmental activities" feed | id, actor, action, created_at |

Relationships: every user-owned table references `users(id)` with `ON DELETE CASCADE`, so removing a user removes
that user's reports, water/waste records, chat and complaints.

## 6. Demo data

`seed_demo_data()` inserts: 1 admin, 4 users, 70 air-quality readings (5 cities x 14 days), 6 environmental reports,
3 water reports, 18 waste reports, 2 complaints and an activity feed. This means dashboards and charts show
meaningful data immediately, with no external sensors.

## 7. AI integration details

| Feature | Function in `ai_service.py` | Claude prompt output | Demo-mode behaviour |
|---|---|---|---|
| Environmental analysis | `analyze_problem()` | JSON: issue_type, severity, summary, causes, health_impact, suggestions, report | Keyword matching against a knowledge base; severity from keywords |
| Chatbot | `chat()` | Conversational answer using the last 10 messages | Topic keyword matching -> predefined answer |
| Air quality advice | `air_quality_advice()` | Health + environment bullet points for the AQI | Advice per AQI band |
| Recommendations | `personalized_recommendations()` | Tips per focus area using city, report count and main waste type | Predefined tips personalised with the user's city |

The system prompt restricts the assistant to environmental topics. Model name is configurable with `CLAUDE_MODEL`.

## 8. Security

* Passwords hashed with Werkzeug (`generate_password_hash`).
* Signed, expiring tokens (itsdangerous, 7 days). Admin-only routes check the role.
* Parameterised SQL everywhere (no string-built queries with user data).
* Upload validation: image extensions only, 5 MB limit, random file names.
* Input validation on frontend and backend; consistent JSON error responses.
* Secrets only in `backend/.env` (ignored by git).

## 9. API documentation

Base URL: `http://localhost:5000` (the React dev server proxies `/api` and `/uploads`).
Responses are JSON. Errors have the form `{"error": "message"}` with status 400 / 401 / 403 / 404 / 409.
Protected routes require `Authorization: Bearer <token>`.

### 9.1 Authentication

**POST /api/auth/register** (public)
```json
{ "name": "Test User", "email": "t@example.com", "password": "secret1", "phone": "", "city": "Chennai",
  "role": "user" }
```
For admin: `"role": "admin", "admin_code": "ECOADMIN2026"`.
Returns `201 {"token": "...", "user": {...}}`. Errors: 400 validation, 403 bad admin code, 409 email exists.

**POST /api/auth/login** (public) - `{"email","password","role":"user|admin"}` -> `{"token","user"}`; 401 if invalid.

**GET /api/auth/me** (login) -> `{"user": {...}}`
**PUT /api/auth/me** (login) - `{"name","phone","city","current_password","new_password"}` -> `{"user"}`

### 9.2 Environmental reports

**GET /api/reports/categories** (public) -> `{"categories": [...], "statuses": [...]}`
**GET /api/reports?status=Pending** (login) -> `{"reports": [...]}` - users see own reports, admin sees all.
**POST /api/reports** (user) - `multipart/form-data`: `title, category, description, location, image (optional)`
-> `201 {"report": {...}}`
**PUT /api/reports/{id}** (admin) - `{"status": "In Progress", "admin_remarks": "text"}` -> `{"report"}`
**DELETE /api/reports/{id}** (login) - admin: any report; user: own *Pending* reports only.
**GET /uploads/{filename}** (public) - uploaded image.

### 9.3 Air quality

**GET /api/air/cities** -> `{"cities": [...]}`
**GET /api/air/current** (public) -> `{"readings": [{city, aqi, pm25, pm10, no2, so2, co, recorded_at, category:{label,color,advice}}]}`
**GET /api/air/history?city=Delhi&limit=14** (public) -> `{"city", "history": [...]}` oldest first
**GET /api/air/advice?city=Delhi** (login) -> `{"city","reading","advice","demo"}`
**POST /api/air/simulate** (login) - `{"city": "Chennai"}` -> `201 {"reading"}` (adds a simulated sensor reading)

### 9.4 Water quality

**GET /api/water/meta** (public) -> `{"sources": [...], "tips": [...]}`
**GET /api/water** (login) -> `{"reports": [...]}`
**POST /api/water** (user) - `{"location","source_type","ph","turbidity","tds","dissolved_oxygen","description"}`
-> `201 {"report","issues":[...]}`. Rules: pH outside 6.5-8.5, turbidity > 5 NTU, TDS > 500 mg/L, dissolved oxygen < 5 mg/L.
**PUT /api/water/{id}** (admin) - `{"status": "Pending|Reviewed|Action Taken"}`

### 9.5 Waste management

**GET /api/waste/guide** (public) -> `{"types": [...], "guide": {type: {bin, segregation, recycling, examples}}}`
**GET /api/waste/stats** (login) -> `{"by_type": [...], "by_status": [...]}`
**GET /api/waste** (login) -> `{"reports": [...]}`
**POST /api/waste** (user) - `{"waste_type","quantity_kg","location","notes"}` -> `201 {"report","guide"}`
**PUT /api/waste/{id}** (admin) - `{"status": "Reported|Scheduled|Collected"}`

### 9.6 AI

**GET /api/ai/status** (public) -> `{"demo_mode": true|false}`
**POST /api/ai/analyze** (login) - `{"description","category","location"}`
-> `{"analysis": {issue_type, severity, summary, causes[], health_impact, suggestions[], report, demo}}`
**POST /api/ai/chat** (login) - `{"message": "How can I reduce plastic waste?"}` -> `{"reply","demo"}`
**GET /api/ai/chat/history** (login) -> `{"messages": [{role, message, created_at}]}`
**DELETE /api/ai/chat/history** (login) - clears the conversation
**POST /api/ai/recommendations** (login) - `{"focus": "all|pollution|waste|water|energy"}` -> `{"content","demo"}`
**GET /api/ai/recommendations/history** (login) -> `{"items": [...]}`

### 9.7 Statistics

**GET /api/stats/overview** (login) -> `{totals, pollution_trend, city_aqi, waste_by_type, waste_by_status, reports_by_category, reports_by_status, reports_per_day}`
**GET /api/stats/download** (login) -> CSV file `ecosmart_report.csv`

### 9.8 Admin

**GET /api/admin/dashboard** -> `{totals:{users,reports,pending_reports,open_complaints,water_reports,waste_kg,avg_aqi}, reports_by_status, reports_by_category, city_aqi, recent_activity}`
**GET /api/admin/users** -> `{"users": [...]}`   **DELETE /api/admin/users/{id}**
**GET /api/admin/complaints** -> `{"complaints": [...], "statuses": [...]}`
**PUT /api/admin/complaints/{id}** - `{"status","admin_response"}`
**GET /api/admin/activities** -> `{"activities": [...]}`
**GET /api/admin/contact-messages** -> `{"messages": [...]}`

### 9.9 Complaints and contact

**GET /api/complaints** (user) -> `{"complaints": [...]}`
**POST /api/complaints** (user) - `{"subject","message"}` -> `201 {"complaint"}`
**POST /api/contact** (public) - `{"name","email","message"}` -> `201 {"message"}`
**GET /api/health** -> `{"status":"ok"}`

## 10. Testing performed

The backend was tested with an automated smoke test using Flask's test client (44 checks) covering: health,
registration validation, duplicate email, admin-code check, login (valid and invalid), token protection, role
protection (user blocked from admin routes), report submission with image upload, invalid image rejection, admin
review and delete, water issue detection, waste submission and invalid type, AI analysis / chatbot /
recommendations in demo mode, complaints, contact form, admin dashboard, statistics and CSV download.
All checks passed in demo mode (no API key).

Manual test checklist for the frontend (see README section 6): login as user/admin, submit each type of report,
check charts update after adding data, chat with the assistant, review a report as admin, download the CSV.

## 11. Limitations and future scope

* Air-quality values are simulated demo data; real sensors or a public AQI API can be connected through
  `routes/air.py` without changing the frontend.
* The default database is SQLite; PostgreSQL/MySQL would be better for many concurrent users.
* Possible extensions: email/SMS alerts, map view of reports, image-based AI analysis of uploaded photos,
  multi-language support, mobile app.

## 12. Conclusion

EcoSmart AI demonstrates how a modern web stack and generative AI can be combined into a practical environmental
management tool with monitoring, reporting, administration and intelligent assistance.
