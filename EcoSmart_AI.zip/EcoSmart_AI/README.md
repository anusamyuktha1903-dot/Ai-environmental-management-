# EcoSmart AI - AI-Centered Environmental Management System

A full-stack college project: a React + Flask + SQLite web application that lets users monitor air quality,
report water pollution and waste, upload environmental issue photos, chat with an AI assistant and receive
personalised recommendations. Administrators review reports, manage complaints and watch pollution statistics.

AI features use the **Claude API (Anthropic)**. If no API key is configured the app runs in **Demo Mode** with
built-in environmental knowledge, so everything can be demonstrated without internet or an API key.

---

## 1. Features

| Module | What it does |
|---|---|
| Admin dashboard | Total users, reports, pollution statistics, complaint management, activity feed |
| AI environmental analysis | Describe a problem -> issue type, severity, causes, solutions, downloadable report |
| Air quality monitoring | AQI, PM2.5, PM10 for 5 cities, trend charts, AI health advice, simulated sensor readings |
| Water quality management | Submit water test values, automatic pollution-issue detection, conservation tips |
| Waste management | 5 waste categories, segregation + recycling guide, collection reports and status tracking |
| Smart reporting | Report problems with location, description and **image upload**; admin review + status tracking |
| AI chatbot | Answers questions on pollution, climate change, deforestation, recycling; history is saved |
| Statistics | Pollution trends, waste statistics, report charts, **downloadable CSV report** |
| AI recommendations | Personalised tips to reduce pollution, recycle, save water and energy |
| User management | Register, login, profile, complaints and complaint status tracking |

**Pages (14 required + extras):** Home, Login, Register, Admin Dashboard, User Dashboard, AI Analysis, Air Quality,
Water Management, Waste Management, Environmental Reports, AI Chatbot, Statistics, About Us, Contact - plus
Recommendations, My Complaints, My Profile, Admin Users and Admin Complaints.

## 2. Project structure

```
EcoSmart_AI/
├── frontend/                React + Vite + Bootstrap 5 + Chart.js
│   ├── public/
│   ├── src/
│   │   ├── components/      layouts, sidebar, shared UI
│   │   ├── pages/           all application pages
│   │   ├── services/        api.js (fetch wrapper), AuthContext, hooks, chart setup
│   │   ├── assets/          styles.css (green & white theme)
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js       dev proxy -> Flask on port 5000
├── backend/                 Python Flask REST API
│   ├── app.py               application entry point
│   ├── config.py            settings (reads environment variables)
│   ├── database.py          SQLite schema, helpers, demo data seeding
│   ├── models/              auth (tokens, decorators) and input validators
│   ├── routes/              one blueprint per feature (auth, reports, air, water, waste, ai, stats, admin, complaints)
│   ├── services/ai_service.py   ALL Claude API calls + demo mode
│   ├── uploads/             uploaded report images
│   ├── requirements.txt
│   └── .env.example
├── database/ecosmart.db     SQLite database (pre-created with demo data)
├── screenshots/             put your screenshots here for the report
├── README.md
├── PROJECT_DOCUMENTATION.md
└── .gitignore
```

## 3. Prerequisites

* **Python 3.10+**  (check: `python --version`)
* **Node.js 18+ and npm**  (check: `node --version`)
* A modern browser (Chrome, Edge, Firefox)
* *(Optional)* an Anthropic API key from <https://console.anthropic.com/> for live Claude responses

## 4. Installation and running - step by step

Open **two terminals** (one for the backend, one for the frontend).

### Step 1 - Backend: install Python dependencies

**Windows (Command Prompt or PowerShell):**
```bat
cd EcoSmart_AI\backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```
> PowerShell may block activation. If so, run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

**macOS / Linux:**
```bash
cd EcoSmart_AI/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Step 2 - Configure the Claude API key (optional)

1. Copy the example file:
   * Windows: `copy .env.example .env`
   * macOS/Linux: `cp .env.example .env`
2. Open `backend/.env` and paste your key:
   ```
   ANTHROPIC_API_KEY=sk-ant-xxxxxxxx
   ```
3. Change `SECRET_KEY` to any long random text.

The key stays **only on the server** (backend). It is never sent to the browser.
**No key? No problem** - leave it empty and the app runs in Demo Mode (a "Demo mode" badge is shown on AI pages).

### Step 3 - Create and initialise the database

The database file `database/ecosmart.db` is already included with demo data. To (re)create it from scratch:

```bash
python database.py
```
This creates all tables and inserts demo users, reports, air quality readings, water and waste data.
(To reset, delete `database/ecosmart.db` and run the command again. The backend also does this automatically on start-up.)

### Step 4 - Start the Flask backend

```bash
python app.py
```
The API now runs at **http://localhost:5000** (health check: <http://localhost:5000/api/health>).
Keep this terminal open.

### Step 5 - Frontend: install dependencies and start

In the **second terminal**:
```bash
cd EcoSmart_AI/frontend
npm install
npm run dev
```

### Step 6 - Open the application

Go to **http://localhost:5173** in your browser.

## 5. Sample login credentials

| Role | Email | Password |
|---|---|---|
| **Admin** | admin@ecosmart.com | Admin@123 |
| **User** | user@ecosmart.com | User@123 |
| User | ravi@example.com | Ravi@123 |
| User | priya@example.com | Priya@123 |
| User | arjun@example.com | Arjun@123 |

On the login page choose **User** or **Admin** first. To register a new **admin**, choose "Admin" on the register
page and enter the code `ECOADMIN2026` (change it in `backend/.env`).

## 6. Suggested demo flow (for viva / presentation)

1. Home page -> live AQI snapshot -> Login as **User**.
2. Air Quality -> select Delhi -> "Get recommendations" -> "Simulate new reading".
3. AI Analysis -> describe a problem -> view the generated report -> download it.
4. Water -> submit pH 5.8, turbidity 12 -> see detected issues.
5. Waste -> pick *Electronic Waste* guide -> submit a collection request.
6. Environmental Reports -> submit a report with a photo.
7. AI Chatbot -> ask "How can I reduce plastic waste?".
8. Logout -> login as **Admin** -> dashboard -> review the report (change status, add remarks) -> manage complaints.
9. Statistics -> Download report (CSV).

## 7. API endpoints (summary)

All endpoints return JSON. Protected endpoints need the header `Authorization: Bearer <token>` (returned by login).
Full request/response details are in `PROJECT_DOCUMENTATION.md`.

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | /api/auth/register | Public | Register user (or admin with code) |
| POST | /api/auth/login | Public | Login, returns token |
| GET / PUT | /api/auth/me | Login | View / update profile |
| GET | /api/reports/categories | Public | Report categories and statuses |
| GET | /api/reports | Login | List reports (own for users, all for admin) |
| POST | /api/reports | User | Submit report (multipart, image optional) |
| PUT | /api/reports/:id | Admin | Update status and remarks |
| DELETE | /api/reports/:id | Login | Delete report |
| GET | /api/air/current | Public | Latest reading per city |
| GET | /api/air/history?city= | Public | Reading history for charts |
| GET | /api/air/advice?city= | Login | AI health / environment advice |
| POST | /api/air/simulate | Login | Add a simulated sensor reading |
| GET / POST | /api/water | Login / User | List / submit water reports |
| PUT | /api/water/:id | Admin | Update status |
| GET | /api/waste/guide | Public | Segregation and recycling guide |
| GET | /api/waste/stats | Login | Totals per type and status |
| GET / POST | /api/waste | Login / User | List / submit waste reports |
| PUT | /api/waste/:id | Admin | Update collection status |
| GET | /api/ai/status | Public | Demo mode or live Claude |
| POST | /api/ai/analyze | Login | AI environmental analysis |
| POST | /api/ai/chat | Login | Chatbot message |
| GET / DELETE | /api/ai/chat/history | Login | Read / clear chat history |
| POST | /api/ai/recommendations | Login | Personalised recommendations |
| GET | /api/ai/recommendations/history | Login | Past recommendations |
| GET | /api/stats/overview | Login | Chart data |
| GET | /api/stats/download | Login | CSV report download |
| GET | /api/admin/dashboard | Admin | Dashboard totals and activity |
| GET / DELETE | /api/admin/users | Admin | List / remove users |
| GET / PUT | /api/admin/complaints | Admin | List / respond to complaints |
| GET / POST | /api/complaints | User | My complaints / submit |
| POST | /api/contact | Public | Contact form |

## 8. Troubleshooting

| Problem | Fix |
|---|---|
| `Cannot reach the server` in the browser | Start the backend (`python app.py`) and keep it running on port 5000. |
| `ModuleNotFoundError` | Activate the virtual environment, then `pip install -r requirements.txt`. |
| `npm` command not found | Install Node.js from <https://nodejs.org> and reopen the terminal. |
| Port 5000 already in use (macOS AirPlay) | Change the port in `backend/app.py` **and** the proxy URLs in `frontend/vite.config.js`. |
| Chatbot says "Demo mode" | `ANTHROPIC_API_KEY` is empty/invalid in `backend/.env`. Restart the backend after editing. |
| Want a fresh database | Delete `database/ecosmart.db`, run `python database.py`. |
| Login fails | Select the correct role (User/Admin) on the login page. |

## 9. Security notes

* Passwords are hashed (Werkzeug). Login tokens are signed and expire after 7 days.
* API keys are read from environment variables on the server only.
* Uploads are restricted to images up to 5 MB and renamed with random names.
* All inputs are validated on both the frontend and the backend; SQL uses parameterised queries.
* Before real deployment: set a strong `SECRET_KEY`, change the admin code, disable `debug=True`, use HTTPS.
