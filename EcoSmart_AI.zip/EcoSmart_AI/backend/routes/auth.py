"""Registration, login and profile endpoints (users and admins)."""
from flask import Blueprint, g, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

from config import Config
from database import execute, log_activity, query
from models.auth import create_token, login_required, public_account
from models.validators import ValidationError, clean_text, valid_email, valid_password

bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@bp.post("/register")
def register():
    """Create a user (default) or an admin (needs the admin registration code)."""
    data = request.get_json(silent=True) or {}
    try:
        name = clean_text(data.get("name"), "Name", min_len=2, max_len=80)
        email = valid_email(data.get("email"))
        password = valid_password(data.get("password"))
        phone = clean_text(data.get("phone"), "Phone", max_len=20, required=False)
        city = clean_text(data.get("city"), "City", max_len=60, required=False)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    role = "admin" if data.get("role") == "admin" else "user"
    if role == "admin" and data.get("admin_code") != Config.ADMIN_REGISTRATION_CODE:
        return jsonify({"error": "Invalid admin registration code."}), 403

    # Email must be unique across both tables
    if query("SELECT id FROM users WHERE email=?", (email,), one=True) or \
       query("SELECT id FROM admin WHERE email=?", (email,), one=True):
        return jsonify({"error": "An account with this email already exists."}), 409

    pw_hash = generate_password_hash(password)
    if role == "admin":
        new_id = execute("INSERT INTO admin (name,email,password_hash) VALUES (?,?,?)", (name, email, pw_hash))
        account = query("SELECT * FROM admin WHERE id=?", (new_id,), one=True)
    else:
        new_id = execute(
            "INSERT INTO users (name,email,password_hash,phone,city) VALUES (?,?,?,?,?)",
            (name, email, pw_hash, phone, city),
        )
        account = query("SELECT * FROM users WHERE id=?", (new_id,), one=True)

    account["role"] = role
    log_activity(name, f"registered a new {role} account")
    return jsonify({"token": create_token(new_id, role), "user": public_account(account)}), 201


@bp.post("/login")
def login():
    """Log in as user or admin. The `role` field selects which table is checked."""
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    role = "admin" if data.get("role") == "admin" else "user"
    if not email or not password:
        return jsonify({"error": "Email and password are required."}), 400

    table = "admin" if role == "admin" else "users"
    account = query(f"SELECT * FROM {table} WHERE email=?", (email,), one=True)
    if not account or not check_password_hash(account["password_hash"], password):
        return jsonify({"error": "Invalid email or password."}), 401

    account["role"] = role
    log_activity(account["name"], f"logged in as {role}")
    return jsonify({"token": create_token(account["id"], role), "user": public_account(account)})


@bp.get("/me")
@login_required
def me():
    return jsonify({"user": public_account(g.account)})


@bp.put("/me")
@login_required
def update_profile():
    """Update name / phone / city (users) or name (admin); optional password change."""
    data = request.get_json(silent=True) or {}
    acc = g.account
    try:
        name = clean_text(data.get("name", acc["name"]), "Name", min_len=2, max_len=80)
        new_password = data.get("new_password")
        pw_hash = acc["password_hash"]
        if new_password:
            if not check_password_hash(acc["password_hash"], data.get("current_password") or ""):
                return jsonify({"error": "Current password is incorrect."}), 400
            pw_hash = generate_password_hash(valid_password(new_password))

        if acc["role"] == "admin":
            execute("UPDATE admin SET name=?, password_hash=? WHERE id=?", (name, pw_hash, acc["id"]))
            updated = query("SELECT * FROM admin WHERE id=?", (acc["id"],), one=True)
        else:
            phone = clean_text(data.get("phone"), "Phone", max_len=20, required=False)
            city = clean_text(data.get("city"), "City", max_len=60, required=False)
            execute(
                "UPDATE users SET name=?, phone=?, city=?, password_hash=? WHERE id=?",
                (name, phone, city, pw_hash, acc["id"]),
            )
            updated = query("SELECT * FROM users WHERE id=?", (acc["id"],), one=True)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    updated["role"] = acc["role"]
    return jsonify({"user": public_account(updated)})
