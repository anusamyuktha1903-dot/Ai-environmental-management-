"""Admin dashboard: totals, users, complaints management, activity feed."""
from flask import Blueprint, jsonify, request

from database import execute, log_activity, query
from models.auth import admin_required
from models.validators import ValidationError, clean_text, one_of

bp = Blueprint("admin", __name__, url_prefix="/api/admin")

COMPLAINT_STATUSES = ["Open", "In Progress", "Resolved", "Closed"]


@bp.get("/dashboard")
@admin_required
def dashboard():
    """Live statistics for the admin dashboard cards and charts."""
    count = lambda sql: query(sql, one=True)["c"]
    avg = query("SELECT ROUND(AVG(aqi),0) AS a FROM air_quality_data WHERE recorded_at >= datetime('now','-3 days')",
                one=True)["a"]
    return jsonify({
        "totals": {
            "users": count("SELECT COUNT(*) AS c FROM users"),
            "reports": count("SELECT COUNT(*) AS c FROM environmental_reports"),
            "pending_reports": count("SELECT COUNT(*) AS c FROM environmental_reports WHERE status='Pending'"),
            "open_complaints": count("SELECT COUNT(*) AS c FROM complaints WHERE status IN ('Open','In Progress')"),
            "water_reports": count("SELECT COUNT(*) AS c FROM water_quality_reports"),
            "waste_kg": count("SELECT ROUND(COALESCE(SUM(quantity_kg),0),1) AS c FROM waste_management"),
            "avg_aqi": avg,
        },
        "reports_by_status": query("SELECT status, COUNT(*) AS count FROM environmental_reports GROUP BY status"),
        "reports_by_category": query(
            "SELECT category, COUNT(*) AS count FROM environmental_reports GROUP BY category"),
        "city_aqi": query(
            "SELECT city, ROUND(AVG(aqi),0) AS avg_aqi FROM air_quality_data GROUP BY city ORDER BY avg_aqi DESC"),
        "recent_activity": query("SELECT * FROM activity_log ORDER BY id DESC LIMIT 8"),
    })


@bp.get("/users")
@admin_required
def users():
    rows = query(
        "SELECT u.id, u.name, u.email, u.phone, u.city, u.created_at, "
        "(SELECT COUNT(*) FROM environmental_reports r WHERE r.user_id=u.id) AS reports "
        "FROM users u ORDER BY u.id DESC")
    return jsonify({"users": rows})


@bp.delete("/users/<int:user_id>")
@admin_required
def delete_user(user_id):
    user = query("SELECT * FROM users WHERE id=?", (user_id,), one=True)
    if not user:
        return jsonify({"error": "User not found."}), 404
    execute("DELETE FROM users WHERE id=?", (user_id,))
    log_activity("Admin", f"removed user {user['name']}")
    return jsonify({"message": "User removed."})


@bp.get("/complaints")
@admin_required
def complaints():
    rows = query(
        "SELECT c.*, u.name AS user_name, u.email AS user_email FROM complaints c "
        "JOIN users u ON u.id=c.user_id ORDER BY c.created_at DESC, c.id DESC")
    return jsonify({"complaints": rows, "statuses": COMPLAINT_STATUSES})


@bp.put("/complaints/<int:complaint_id>")
@admin_required
def update_complaint(complaint_id):
    data = request.get_json(silent=True) or {}
    complaint = query("SELECT * FROM complaints WHERE id=?", (complaint_id,), one=True)
    if not complaint:
        return jsonify({"error": "Complaint not found."}), 404
    try:
        status = one_of(data.get("status"), "Status", COMPLAINT_STATUSES)
        response = clean_text(data.get("admin_response"), "Response", max_len=500, required=False)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400
    execute("UPDATE complaints SET status=?, admin_response=? WHERE id=?", (status, response, complaint_id))
    log_activity("Admin", f"updated complaint '{complaint['subject']}' to {status}")
    return jsonify({"complaint": query("SELECT * FROM complaints WHERE id=?", (complaint_id,), one=True)})


@bp.get("/activities")
@admin_required
def activities():
    return jsonify({"activities": query("SELECT * FROM activity_log ORDER BY id DESC LIMIT 50")})


@bp.get("/contact-messages")
@admin_required
def contact_messages():
    return jsonify({"messages": query("SELECT * FROM contact_messages ORDER BY id DESC")})
