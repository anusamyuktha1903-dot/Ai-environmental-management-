"""AI endpoints: environmental analysis, chatbot and personalised recommendations."""
import json

from flask import Blueprint, g, jsonify, request

from database import execute, query
from models.auth import login_required
from models.validators import ValidationError, clean_text
from services import ai_service

bp = Blueprint("ai", __name__, url_prefix="/api/ai")


@bp.get("/status")
def status():
    """Tells the frontend whether Claude is live or the app is in demo mode."""
    return jsonify({"demo_mode": ai_service.is_demo_mode()})


@bp.post("/analyze")
@login_required
def analyze():
    """Analyse a problem description and store the result as a recommendation."""
    data = request.get_json(silent=True) or {}
    try:
        description = clean_text(data.get("description"), "Description", min_len=10, max_len=2000)
        category = clean_text(data.get("category"), "Category", max_len=60, required=False)
        location = clean_text(data.get("location"), "Location", max_len=150, required=False)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    result = ai_service.analyze_problem(description, category, location)
    execute(
        "INSERT INTO ai_recommendations (user_id,kind,input_text,content) VALUES (?,?,?,?)",
        (g.account["id"] if g.account["role"] == "user" else _admin_user_id(),
         "analysis", description[:500], json.dumps(result)),
    )
    return jsonify({"analysis": result})


def _admin_user_id():
    """ai_recommendations/chat_history reference users; admins use the first demo user id
    only if no user exists. Admin AI usage is simply not stored in that case."""
    row = query("SELECT id FROM users ORDER BY id LIMIT 1", one=True)
    return row["id"] if row else 1


@bp.post("/chat")
@login_required
def chat():
    """Chatbot: keeps the last 10 messages as context and stores the conversation."""
    data = request.get_json(silent=True) or {}
    try:
        message = clean_text(data.get("message"), "Message", max_len=1000)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    uid = g.account["id"] if g.account["role"] == "user" else _admin_user_id()
    recent = query(
        "SELECT role, message FROM chat_history WHERE user_id=? ORDER BY id DESC LIMIT 10", (uid,))
    recent.reverse()
    history = [{"role": r["role"], "content": r["message"]} for r in recent]

    result = ai_service.chat(history, message)
    execute("INSERT INTO chat_history (user_id,role,message) VALUES (?,?,?)", (uid, "user", message))
    execute("INSERT INTO chat_history (user_id,role,message) VALUES (?,?,?)", (uid, "assistant", result["reply"]))
    return jsonify(result)


@bp.get("/chat/history")
@login_required
def chat_history():
    uid = g.account["id"] if g.account["role"] == "user" else _admin_user_id()
    rows = query("SELECT role, message, created_at FROM chat_history WHERE user_id=? ORDER BY id DESC LIMIT 50", (uid,))
    rows.reverse()
    return jsonify({"messages": rows})


@bp.delete("/chat/history")
@login_required
def clear_chat():
    uid = g.account["id"] if g.account["role"] == "user" else _admin_user_id()
    execute("DELETE FROM chat_history WHERE user_id=?", (uid,))
    return jsonify({"message": "Chat history cleared."})


@bp.post("/recommendations")
@login_required
def recommendations():
    """Personalised recommendations based on the user's profile and activity."""
    data = request.get_json(silent=True) or {}
    focus = data.get("focus", "all")
    if focus not in ("all", "pollution", "waste", "water", "energy"):
        return jsonify({"error": "Invalid focus area."}), 400

    acc = g.account
    profile = {"city": acc.get("city") or "", "reports_count": 0, "waste_kg": 0, "main_waste": None}
    if acc["role"] == "user":
        profile["reports_count"] = query(
            "SELECT COUNT(*) AS c FROM environmental_reports WHERE user_id=?", (acc["id"],), one=True)["c"]
        top = query(
            "SELECT waste_type, SUM(quantity_kg) AS kg FROM waste_management WHERE user_id=? "
            "GROUP BY waste_type ORDER BY kg DESC LIMIT 1", (acc["id"],), one=True)
        if top:
            profile["main_waste"], profile["waste_kg"] = top["waste_type"], round(top["kg"], 1)

    result = ai_service.personalized_recommendations(profile, focus)
    if acc["role"] == "user":
        execute("INSERT INTO ai_recommendations (user_id,kind,input_text,content) VALUES (?,?,?,?)",
                (acc["id"], f"recommendation:{focus}", json.dumps(profile), result["content"]))
    return jsonify(result)


@bp.get("/recommendations/history")
@login_required
def recommendation_history():
    uid = g.account["id"] if g.account["role"] == "user" else _admin_user_id()
    rows = query("SELECT id, kind, input_text, content, created_at FROM ai_recommendations "
                 "WHERE user_id=? ORDER BY id DESC LIMIT 20", (uid,))
    return jsonify({"items": rows})
