"""Water quality management: submit reports, auto-detect issues, conservation tips."""
from flask import Blueprint, g, jsonify, request

from database import execute, log_activity, query
from models.auth import admin_required, login_required
from models.validators import ValidationError, clean_text, one_of, optional_float

bp = Blueprint("water", __name__, url_prefix="/api/water")

SOURCES = ["River", "Lake", "Pond", "Well", "Tap Water", "Groundwater", "Other"]
STATUSES = ["Pending", "Reviewed", "Action Taken"]

CONSERVATION_TIPS = [
    {"title": "Fix leaks quickly", "tip": "A dripping tap can waste over 20 litres a day. Repair leaks right away."},
    {"title": "Harvest rainwater", "tip": "Collect roof run-off in tanks or recharge pits to raise groundwater levels."},
    {"title": "Reuse grey water", "tip": "Use washing and RO reject water for gardening, mopping and flushing."},
    {"title": "Shorter showers", "tip": "A 5-minute shower with a low-flow head can save 50+ litres each time."},
    {"title": "Water plants smartly", "tip": "Water in early morning or evening and use drip irrigation or mulch."},
    {"title": "Keep water clean", "tip": "Never dump oil, paint, chemicals or garbage into drains or water bodies."},
]


def detect_issues(ph, turbidity, tds, dissolved_oxygen):
    """Rule-based screening against common drinking / surface water limits."""
    issues = []
    if ph is not None:
        if ph < 6.5:
            issues.append("Low pH (acidic)")
        elif ph > 8.5:
            issues.append("High pH (alkaline)")
    if turbidity is not None and turbidity > 5:
        issues.append("High turbidity (suspended particles)")
    if tds is not None and tds > 500:
        issues.append("High TDS (dissolved solids / salts)")
    if dissolved_oxygen is not None and dissolved_oxygen < 5:
        issues.append("Low dissolved oxygen (harms aquatic life)")
    return issues


@bp.get("/meta")
def meta():
    return jsonify({"sources": SOURCES, "tips": CONSERVATION_TIPS})


@bp.get("")
@login_required
def list_water():
    sql = ("SELECT w.*, u.name AS user_name FROM water_quality_reports w "
           "JOIN users u ON u.id = w.user_id")
    params = ()
    if g.account["role"] != "admin":
        sql += " WHERE w.user_id = ?"
        params = (g.account["id"],)
    sql += " ORDER BY w.created_at DESC, w.id DESC"
    return jsonify({"reports": query(sql, params)})


@bp.post("")
@login_required
def create_water():
    if g.account["role"] == "admin":
        return jsonify({"error": "Administrators cannot submit water reports."}), 403
    data = request.get_json(silent=True) or {}
    try:
        location = clean_text(data.get("location"), "Location", min_len=3, max_len=150)
        source = one_of(data.get("source_type"), "Source type", SOURCES)
        ph = optional_float(data.get("ph"), "pH", 0, 14)
        turbidity = optional_float(data.get("turbidity"), "Turbidity", 0, 1000)
        tds = optional_float(data.get("tds"), "TDS", 0, 50000)
        do = optional_float(data.get("dissolved_oxygen"), "Dissolved oxygen", 0, 30)
        description = clean_text(data.get("description"), "Description", max_len=1000, required=False)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    issues = detect_issues(ph, turbidity, tds, do)
    if any(w in description.lower() for w in ["smell", "oil", "sewage", "foam", "dead fish", "colour", "color"]):
        issues.append("Visible contamination reported in description")
    issues_text = "; ".join(issues) if issues else "No major issues detected"

    new_id = execute(
        "INSERT INTO water_quality_reports (user_id,location,source_type,ph,turbidity,tds,"
        "dissolved_oxygen,description,issues_detected) VALUES (?,?,?,?,?,?,?,?,?)",
        (g.account["id"], location, source, ph, turbidity, tds, do, description, issues_text),
    )
    log_activity(g.account["name"], f"submitted a water quality report for {location}")
    report = query("SELECT * FROM water_quality_reports WHERE id=?", (new_id,), one=True)
    return jsonify({"report": report, "issues": issues}), 201


@bp.put("/<int:report_id>")
@admin_required
def update_status(report_id):
    data = request.get_json(silent=True) or {}
    if not query("SELECT id FROM water_quality_reports WHERE id=?", (report_id,), one=True):
        return jsonify({"error": "Report not found."}), 404
    try:
        status = one_of(data.get("status"), "Status", STATUSES)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400
    execute("UPDATE water_quality_reports SET status=? WHERE id=?", (status, report_id))
    log_activity(g.account["name"], f"set water report #{report_id} to {status}")
    return jsonify({"report": query("SELECT * FROM water_quality_reports WHERE id=?", (report_id,), one=True)})
