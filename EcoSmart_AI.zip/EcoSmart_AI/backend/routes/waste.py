"""Waste management: categories, segregation + recycling guide, collection reports."""
from flask import Blueprint, g, jsonify, request

from database import execute, log_activity, query
from models.auth import admin_required, login_required
from models.validators import ValidationError, clean_text, one_of, optional_float

bp = Blueprint("waste", __name__, url_prefix="/api/waste")

STATUSES = ["Reported", "Scheduled", "Collected"]

# Static guide shown on the Waste Management page
WASTE_GUIDE = {
    "Plastic Waste": {
        "bin": "Dry waste (Blue bin)",
        "segregation": "Rinse containers, remove caps and keep plastic dry and separate from food waste.",
        "recycling": "Send PET bottles and HDPE containers to recyclers; avoid single-use plastic; reuse bags and jars.",
        "examples": "Bottles, bags, wrappers, containers",
    },
    "Paper Waste": {
        "bin": "Dry waste (Blue bin)",
        "segregation": "Keep paper dry and clean; flatten cardboard; separate greasy paper (like pizza boxes).",
        "recycling": "Recycle clean paper and cardboard; use both sides; shred unusable paper for compost.",
        "examples": "Newspapers, books, cartons, notebooks",
    },
    "Food Waste": {
        "bin": "Wet waste (Green bin)",
        "segregation": "Collect leftovers and peels separately; no plastic bags inside the wet bin.",
        "recycling": "Compost at home or community level; feed safe leftovers to animals; plan meals to reduce waste.",
        "examples": "Leftovers, peels, spoiled food",
    },
    "Electronic Waste": {
        "bin": "Hazardous / E-waste (Red bin or collection centre)",
        "segregation": "Never mix with household waste; remove batteries; keep devices intact.",
        "recycling": "Donate working devices; give broken ones to authorised e-waste recyclers or take-back programmes.",
        "examples": "Phones, chargers, batteries, laptops, bulbs",
    },
    "Organic Waste": {
        "bin": "Wet waste (Green bin)",
        "segregation": "Collect garden trimmings, leaves and biodegradable material separately.",
        "recycling": "Make compost or vermicompost; use dry leaves as mulch; never burn leaves.",
        "examples": "Leaves, grass, flowers, garden trimmings",
    },
}
WASTE_TYPES = list(WASTE_GUIDE.keys())


@bp.get("/guide")
def guide():
    return jsonify({"types": WASTE_TYPES, "guide": WASTE_GUIDE})


@bp.get("/stats")
@login_required
def stats():
    """Totals per waste type and per status (all data for admin, own data for users)."""
    where, params = "", ()
    if g.account["role"] != "admin":
        where, params = " WHERE user_id = ?", (g.account["id"],)
    by_type = query(
        f"SELECT waste_type, COUNT(*) AS reports, ROUND(SUM(quantity_kg),1) AS total_kg "
        f"FROM waste_management{where} GROUP BY waste_type", params)
    by_status = query(
        f"SELECT status, COUNT(*) AS count FROM waste_management{where} GROUP BY status", params)
    return jsonify({"by_type": by_type, "by_status": by_status})


@bp.get("")
@login_required
def list_waste():
    sql = ("SELECT w.*, u.name AS user_name FROM waste_management w JOIN users u ON u.id = w.user_id")
    params = ()
    if g.account["role"] != "admin":
        sql += " WHERE w.user_id = ?"
        params = (g.account["id"],)
    sql += " ORDER BY w.created_at DESC, w.id DESC"
    return jsonify({"reports": query(sql, params)})


@bp.post("")
@login_required
def create_waste():
    if g.account["role"] == "admin":
        return jsonify({"error": "Administrators cannot submit waste reports."}), 403
    data = request.get_json(silent=True) or {}
    try:
        waste_type = one_of(data.get("waste_type"), "Waste type", WASTE_TYPES)
        qty = optional_float(data.get("quantity_kg"), "Quantity", 0.1, 100000)
        if qty is None:
            raise ValidationError("Quantity is required.")
        location = clean_text(data.get("location"), "Location", min_len=3, max_len=150)
        notes = clean_text(data.get("notes"), "Notes", max_len=500, required=False)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    new_id = execute(
        "INSERT INTO waste_management (user_id,waste_type,quantity_kg,location,notes) VALUES (?,?,?,?,?)",
        (g.account["id"], waste_type, qty, location, notes),
    )
    log_activity(g.account["name"], f"reported {qty} kg of {waste_type} at {location}")
    return jsonify({"report": query("SELECT * FROM waste_management WHERE id=?", (new_id,), one=True),
                    "guide": WASTE_GUIDE[waste_type]}), 201


@bp.put("/<int:waste_id>")
@admin_required
def update_status(waste_id):
    data = request.get_json(silent=True) or {}
    if not query("SELECT id FROM waste_management WHERE id=?", (waste_id,), one=True):
        return jsonify({"error": "Waste report not found."}), 404
    try:
        status = one_of(data.get("status"), "Status", STATUSES)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400
    execute("UPDATE waste_management SET status=? WHERE id=?", (status, waste_id))
    log_activity(g.account["name"], f"set waste collection #{waste_id} to {status}")
    return jsonify({"report": query("SELECT * FROM waste_management WHERE id=?", (waste_id,), one=True)})
