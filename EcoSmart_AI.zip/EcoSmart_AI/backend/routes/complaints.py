"""User complaints (submit + track) and the public contact form."""
from flask import Blueprint, g, jsonify, request

from database import execute, log_activity, query
from models.auth import login_required
from models.validators import ValidationError, clean_text, valid_email

bp = Blueprint("complaints", __name__, url_prefix="/api")


@bp.get("/complaints")
@login_required
def my_complaints():
    """Complaints submitted by the logged-in user, with admin responses and status."""
    if g.account["role"] == "admin":
        return jsonify({"complaints": []})
    rows = query("SELECT * FROM complaints WHERE user_id=? ORDER BY created_at DESC, id DESC", (g.account["id"],))
    return jsonify({"complaints": rows})


@bp.post("/complaints")
@login_required
def create_complaint():
    if g.account["role"] == "admin":
        return jsonify({"error": "Administrators cannot submit complaints."}), 403
    data = request.get_json(silent=True) or {}
    try:
        subject = clean_text(data.get("subject"), "Subject", min_len=4, max_len=120)
        message = clean_text(data.get("message"), "Message", min_len=10, max_len=1500)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400
    new_id = execute("INSERT INTO complaints (user_id,subject,message) VALUES (?,?,?)",
                     (g.account["id"], subject, message))
    log_activity(g.account["name"], f"submitted complaint '{subject}'")
    return jsonify({"complaint": query("SELECT * FROM complaints WHERE id=?", (new_id,), one=True)}), 201


@bp.post("/contact")
def contact():
    """Public contact form (no login needed)."""
    data = request.get_json(silent=True) or {}
    try:
        name = clean_text(data.get("name"), "Name", min_len=2, max_len=80)
        email = valid_email(data.get("email"))
        message = clean_text(data.get("message"), "Message", min_len=10, max_len=1500)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400
    execute("INSERT INTO contact_messages (name,email,message) VALUES (?,?,?)", (name, email, message))
    return jsonify({"message": "Thank you! Your message has been received."}), 201
