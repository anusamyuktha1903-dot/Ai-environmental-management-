"""Flask blueprints (one module per feature area)."""
from .auth import bp as auth_bp
from .reports import bp as reports_bp
from .air import bp as air_bp
from .water import bp as water_bp
from .waste import bp as waste_bp
from .ai import bp as ai_bp
from .stats import bp as stats_bp
from .admin import bp as admin_bp
from .complaints import bp as complaints_bp

ALL_BLUEPRINTS = [
    auth_bp, reports_bp, air_bp, water_bp, waste_bp,
    ai_bp, stats_bp, admin_bp, complaints_bp,
]
