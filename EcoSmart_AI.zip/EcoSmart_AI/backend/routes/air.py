"""Air quality monitoring: latest readings, history, AI advice, simulated sensor reading."""
import random
from datetime import datetime

from flask import Blueprint, jsonify, request

from database import CITIES, CITY_BASE_AQI, execute, query
from models.auth import login_required
from services import ai_service

bp = Blueprint("air", __name__, url_prefix="/api/air")


def _with_category(row):
    row["category"] = ai_service.aqi_category(row["aqi"])
    return row


@bp.get("/cities")
def cities():
    return jsonify({"cities": CITIES})


@bp.get("/current")
def current():
    """Latest reading for every city (public so the home page can show it)."""
    rows = query(
        "SELECT a.* FROM air_quality_data a JOIN "
        "(SELECT city, MAX(recorded_at) AS m FROM air_quality_data GROUP BY city) t "
        "ON a.city = t.city AND a.recorded_at = t.m ORDER BY a.city"
    )
    return jsonify({"readings": [_with_category(r) for r in rows]})


@bp.get("/history")
def history():
    """Readings for one city (default Chennai), oldest first, for charts."""
    city = request.args.get("city", "Chennai")
    limit = min(int(request.args.get("limit", 14)), 90)
    rows = query(
        "SELECT * FROM air_quality_data WHERE city=? ORDER BY recorded_at DESC LIMIT ?",
        (city, limit),
    )
    rows.reverse()
    return jsonify({"city": city, "history": rows})


@bp.get("/advice")
@login_required
def advice():
    """AI health and environmental recommendations for a city's latest reading."""
    city = request.args.get("city", "Chennai")
    row = query(
        "SELECT * FROM air_quality_data WHERE city=? ORDER BY recorded_at DESC LIMIT 1",
        (city,), one=True,
    )
    if not row:
        return jsonify({"error": "No data for that city."}), 404
    result = ai_service.air_quality_advice(city, row["aqi"], row["pm25"], row["pm10"])
    return jsonify({"city": city, "reading": _with_category(row), **result})


@bp.post("/simulate")
@login_required
def simulate():
    """Create a new simulated sensor reading (demo data - no hardware needed)."""
    city = (request.get_json(silent=True) or {}).get("city", "Chennai")
    if city not in CITIES:
        return jsonify({"error": "Unknown city."}), 400
    aqi = max(20, int(CITY_BASE_AQI[city] + random.randint(-35, 45)))
    pm25 = round(aqi * random.uniform(0.35, 0.5), 1)
    pm10 = round(pm25 * random.uniform(1.4, 2.0), 1)
    new_id = execute(
        "INSERT INTO air_quality_data (city,aqi,pm25,pm10,no2,so2,co,recorded_at) VALUES (?,?,?,?,?,?,?,?)",
        (city, aqi, pm25, pm10, round(random.uniform(15, 70), 1), round(random.uniform(5, 30), 1),
         round(random.uniform(0.4, 2.5), 2), datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    )
    row = query("SELECT * FROM air_quality_data WHERE id=?", (new_id,), one=True)
    return jsonify({"reading": _with_category(row)}), 201
