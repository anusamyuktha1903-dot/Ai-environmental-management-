"""Smart environmental reporting: submit (with image), list, review, delete."""
import os
import uuid

from flask import Blueprint, g, jsonify, request
from werkzeug.utils import secure_filename

from config import Config
from database import execute, log_activity, query
from models.auth import admin_required, login_required
from models.validators import ValidationError, clean_text, one_of

bp = Blueprint("reports", __name__, url_prefix="/api/reports")

CATEGORIES = ["Air Pollution", "Water Pollution", "Waste Dumping", "Deforestation",
              "Noise Pollution", "Soil Pollution", "Other"]
STATUSES = ["Pending", "In Progress", "Resolved", "Rejected"]


def _save_image(file):
    """Validate and store an uploaded image; return the stored file name."""
    ext = os.path.splitext(secure_filename(file.filename))[1].lower().lstrip(".")
    if ext not in Config.ALLOWED_EXTENSIONS:
        raise ValidationError("Image must be PNG, JPG, GIF or WEBP.")
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    name = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(Config.UPLOAD_FOLDER, name))
    return name


@bp.get("/categories")
def categories():
    return jsonify({"categories": CATEGORIES, "statuses": STATUSES})


@bp.get("")
@login_required
def list_reports():
    """Admins see all reports; users see only their own. Optional ?status= filter."""
    status = request.args.get("status")
    sql = ("SELECT r.*, u.name AS user_name, u.email AS user_email FROM environmental_reports r "
           "JOIN users u ON u.id = r.user_id")
    clauses, params = [], []
    if g.account["role"] != "admin":
        clauses.append("r.user_id = ?")
        params.append(g.account["id"])
    if status and status in STATUSES:
        clauses.append("r.status = ?")
        params.append(status)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY r.created_at DESC, r.id DESC"
    return jsonify({"reports": query(sql, tuple(params))})


@bp.post("")
@login_required
def create_report():
    """Submit a report (multipart/form-data so an image can be attached)."""
    if g.account["role"] == "admin":
        return jsonify({"error": "Administrators cannot submit reports. Use a user account."}), 403
    form = request.form
    try:
        title = clean_text(form.get("title"), "Title", min_len=4, max_len=120)
        category = one_of(form.get("category"), "Category", CATEGORIES)
        description = clean_text(form.get("description"), "Description", min_len=10, max_len=2000)
        location = clean_text(form.get("location"), "Location", min_len=3, max_len=150)
        image_name = None
        file = request.files.get("image")
        if file and file.filename:
            image_name = _save_image(file)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    new_id = execute(
        "INSERT INTO environmental_reports (user_id,title,category,description,location,image_path)"
        " VALUES (?,?,?,?,?,?)",
        (g.account["id"], title, category, description, location, image_name),
    )
    log_activity(g.account["name"], f"submitted report '{title}'")
    report = query("SELECT * FROM environmental_reports WHERE id=?", (new_id,), one=True)
    return jsonify({"report": report}), 201


@bp.put("/<int:report_id>")
@admin_required
def review_report(report_id):
    """Admin updates the status and remarks of a report."""
    data = request.get_json(silent=True) or {}
    report = query("SELECT * FROM environmental_reports WHERE id=?", (report_id,), one=True)
    if not report:
        return jsonify({"error": "Report not found."}), 404
    try:
        status = one_of(data.get("status"), "Status", STATUSES)
        remarks = clean_text(data.get("admin_remarks"), "Remarks", max_len=500, required=False)
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    execute(
        "UPDATE environmental_reports SET status=?, admin_remarks=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (status, remarks, report_id),
    )
    log_activity(g.account["name"], f"marked report '{report['title']}' as {status}")
    return jsonify({"report": query("SELECT * FROM environmental_reports WHERE id=?", (report_id,), one=True)})


@bp.delete("/<int:report_id>")
@login_required
def delete_report(report_id):
    """Admins can delete any report; users only their own Pending reports."""
    report = query("SELECT * FROM environmental_reports WHERE id=?", (report_id,), one=True)
    if not report:
        return jsonify({"error": "Report not found."}), 404
    if g.account["role"] != "admin":
        if report["user_id"] != g.account["id"]:
            return jsonify({"error": "You can only delete your own reports."}), 403
        if report["status"] != "Pending":
            return jsonify({"error": "Only pending reports can be deleted."}), 400

    if report["image_path"]:
        try:
            os.remove(os.path.join(Config.UPLOAD_FOLDER, report["image_path"]))
        except OSError:
            pass
    execute("DELETE FROM environmental_reports WHERE id=?", (report_id,))
    log_activity(g.account["name"], f"deleted report '{report['title']}'")
    return jsonify({"message": "Report deleted."})
