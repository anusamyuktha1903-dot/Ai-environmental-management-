"""Environmental statistics (charts data) and downloadable CSV report."""
import csv
import io
from datetime import datetime

from flask import Blueprint, Response, jsonify

from database import query
from models.auth import login_required

bp = Blueprint("stats", __name__, url_prefix="/api/stats")


@bp.get("/overview")
@login_required
def overview():
    """All datasets needed by the Statistics page charts (computed from the database)."""
    pollution_trend = query(
        "SELECT substr(recorded_at,1,10) AS day, ROUND(AVG(aqi),0) AS avg_aqi, "
        "ROUND(AVG(pm25),1) AS avg_pm25, ROUND(AVG(pm10),1) AS avg_pm10 "
        "FROM air_quality_data GROUP BY day ORDER BY day")
    city_aqi = query(
        "SELECT city, ROUND(AVG(aqi),0) AS avg_aqi FROM air_quality_data GROUP BY city ORDER BY avg_aqi DESC")
    waste_by_type = query(
        "SELECT waste_type, ROUND(SUM(quantity_kg),1) AS total_kg, COUNT(*) AS reports "
        "FROM waste_management GROUP BY waste_type ORDER BY total_kg DESC")
    waste_by_status = query("SELECT status, COUNT(*) AS count FROM waste_management GROUP BY status")
    reports_by_category = query(
        "SELECT category, COUNT(*) AS count FROM environmental_reports GROUP BY category ORDER BY count DESC")
    reports_by_status = query("SELECT status, COUNT(*) AS count FROM environmental_reports GROUP BY status")
    reports_per_day = query(
        "SELECT substr(created_at,1,10) AS day, COUNT(*) AS count FROM environmental_reports "
        "GROUP BY day ORDER BY day")
    totals = {
        "users": query("SELECT COUNT(*) AS c FROM users", one=True)["c"],
        "reports": query("SELECT COUNT(*) AS c FROM environmental_reports", one=True)["c"],
        "water_reports": query("SELECT COUNT(*) AS c FROM water_quality_reports", one=True)["c"],
        "waste_kg": query("SELECT ROUND(COALESCE(SUM(quantity_kg),0),1) AS c FROM waste_management", one=True)["c"],
        "resolved": query("SELECT COUNT(*) AS c FROM environmental_reports WHERE status='Resolved'", one=True)["c"],
    }
    return jsonify({
        "totals": totals, "pollution_trend": pollution_trend, "city_aqi": city_aqi,
        "waste_by_type": waste_by_type, "waste_by_status": waste_by_status,
        "reports_by_category": reports_by_category, "reports_by_status": reports_by_status,
        "reports_per_day": reports_per_day,
    })


@bp.get("/download")
@login_required
def download():
    """Download a CSV summary report (opens in Excel)."""
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["EcoSmart AI - Environmental Report"])
    w.writerow(["Generated", datetime.now().strftime("%Y-%m-%d %H:%M")])
    w.writerow([])

    w.writerow(["AIR QUALITY (average per city)"])
    w.writerow(["City", "Average AQI", "Average PM2.5", "Average PM10"])
    for r in query("SELECT city, ROUND(AVG(aqi),0) a, ROUND(AVG(pm25),1) b, ROUND(AVG(pm10),1) c "
                   "FROM air_quality_data GROUP BY city"):
        w.writerow([r["city"], r["a"], r["b"], r["c"]])
    w.writerow([])

    w.writerow(["WASTE MANAGEMENT"])
    w.writerow(["Waste type", "Reports", "Total kg"])
    for r in query("SELECT waste_type, COUNT(*) n, ROUND(SUM(quantity_kg),1) kg "
                   "FROM waste_management GROUP BY waste_type"):
        w.writerow([r["waste_type"], r["n"], r["kg"]])
    w.writerow([])

    w.writerow(["ENVIRONMENTAL REPORTS"])
    w.writerow(["ID", "Title", "Category", "Location", "Status", "Date"])
    for r in query("SELECT id,title,category,location,status,created_at FROM environmental_reports ORDER BY id"):
        w.writerow([r["id"], r["title"], r["category"], r["location"], r["status"], r["created_at"]])

    return Response(
        out.getvalue(), mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=ecosmart_report.csv"},
    )
