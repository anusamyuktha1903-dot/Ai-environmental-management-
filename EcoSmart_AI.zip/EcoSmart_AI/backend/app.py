"""EcoSmart AI - Flask application entry point.

Run:  python app.py      (serves the API on http://localhost:5000)
"""
import os

from flask import Flask, jsonify, request, send_from_directory

try:
    from flask_cors import CORS
except ImportError:  # flask-cors not installed: a tiny built-in fallback is used below
    CORS = None

from config import Config
from database import setup
from routes import ALL_BLUEPRINTS


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

    # Allow the React dev server to call this API
    if CORS is not None:
        CORS(app, resources={r"/api/*": {"origins": Config.CORS_ORIGINS}})
    else:
        @app.after_request
        def add_cors_headers(resp):
            origin = request.headers.get("Origin")
            if origin in Config.CORS_ORIGINS:
                resp.headers["Access-Control-Allow-Origin"] = origin
                resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
                resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
            return resp

        @app.before_request
        def preflight():
            # Answer CORS preflight requests without needing a route per URL
            if request.method == "OPTIONS":
                return ("", 204)

    # Create tables + demo data on first start
    setup()

    for blueprint in ALL_BLUEPRINTS:
        app.register_blueprint(blueprint)

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "app": "EcoSmart AI"})

    @app.get("/uploads/<path:filename>")
    def uploaded_file(filename):
        """Serve uploaded report images."""
        return send_from_directory(Config.UPLOAD_FOLDER, filename)

    # ---- JSON error handlers so the frontend always gets a readable message ----
    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": "Resource not found."}), 404

    @app.errorhandler(405)
    def not_allowed(_):
        return jsonify({"error": "Method not allowed."}), 405

    @app.errorhandler(413)
    def too_large(_):
        return jsonify({"error": "File too large. Maximum size is 5 MB."}), 413

    @app.errorhandler(500)
    def server_error(err):
        print(f"[error] {err}")
        return jsonify({"error": "Something went wrong on the server."}), 500

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
