"""AI service: all communication with the Claude (Anthropic) API lives here.

* The API key is read from the ANTHROPIC_API_KEY environment variable only.
* If no key is configured (or the API call fails) every function falls back to
  DEMO MODE, which returns predefined environmental knowledge so the whole
  project can still be demonstrated without internet or an API key.
"""
import json
import re

from config import Config

try:  # the SDK is optional at import time so demo mode always works
    import anthropic
except ImportError:  # pragma: no cover
    anthropic = None

SYSTEM_PROMPT = (
    "You are EcoSmart AI, a friendly and knowledgeable environmental assistant. "
    "You help users with air pollution, water pollution, waste management, climate "
    "change, global warming, deforestation, recycling, energy and water saving, and "
    "environmental protection. Give accurate, practical, concise answers (use short "
    "paragraphs or bullet points). If a question is unrelated to the environment, "
    "politely steer the conversation back to environmental topics."
)

_client = None


def is_demo_mode():
    """True when Claude cannot be used (no key or SDK missing)."""
    return not Config.ANTHROPIC_API_KEY or anthropic is None


def _get_client():
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
    return _client


def _ask_claude(messages, system=SYSTEM_PROMPT, max_tokens=900):
    """Send messages to Claude and return the text reply."""
    response = _get_client().messages.create(
        model=Config.CLAUDE_MODEL,
        max_tokens=max_tokens,
        system=system,
        messages=messages,
    )
    return "".join(b.text for b in response.content if getattr(b, "type", "") == "text").strip()


# ---------------------------------------------------------------------------
# DEMO KNOWLEDGE BASE (used when no API key is available)
# ---------------------------------------------------------------------------
KNOWLEDGE = {
    "air": {
        "keywords": ["air", "smog", "aqi", "pm2.5", "pm10", "smoke", "emission", "fume", "dust"],
        "issue": "Air Pollution",
        "answer": (
            "Air pollution is caused mainly by vehicle exhaust, industrial emissions, burning "
            "of waste/crop residue and construction dust. Fine particles (PM2.5) can enter the "
            "lungs and bloodstream and cause asthma, heart disease and reduced lung function.\n\n"
            "What you can do:\n"
            "- Use public transport, cycling or carpooling.\n"
            "- Never burn plastic, leaves or garbage.\n"
            "- Plant trees and keep indoor plants.\n"
            "- On high-AQI days wear an N95 mask and avoid outdoor exercise."
        ),
        "suggestions": [
            "Report the polluting source to the local pollution control board.",
            "Install dust/fume control (filters, scrubbers, water sprinkling) at the source.",
            "Shift to public transport, EVs and cleaner fuels.",
            "Increase green cover and green belts around the affected area.",
        ],
    },
    "water": {
        "keywords": ["water", "river", "lake", "sewage", "drain", "pond", "oil", "effluent", "ph", "turbid"],
        "issue": "Water Pollution",
        "answer": (
            "Water pollution comes from untreated sewage, industrial effluents, agricultural "
            "run-off (fertilisers and pesticides) and dumped plastic. It harms aquatic life and "
            "spreads diseases such as cholera and typhoid.\n\n"
            "What you can do:\n"
            "- Never throw garbage, oil or chemicals into drains or water bodies.\n"
            "- Fix leaking taps, harvest rainwater and reuse grey water for plants.\n"
            "- Support sewage treatment and use eco-friendly cleaning products."
        ),
        "suggestions": [
            "Stop the discharge of untreated sewage/effluent into the water body.",
            "Test water for pH, turbidity, TDS and dissolved oxygen regularly.",
            "Clean floating waste and install trash barriers.",
            "Promote rainwater harvesting and wastewater recycling.",
        ],
    },
    "waste": {
        "keywords": ["waste", "garbage", "trash", "dump", "litter", "landfill", "segregat", "compost"],
        "issue": "Waste Management",
        "answer": (
            "Good waste management follows Reduce - Reuse - Recycle. Segregate at source into "
            "wet (food/organic), dry (plastic, paper, metal, glass), e-waste and hazardous waste.\n\n"
            "- Compost kitchen and garden waste.\n"
            "- Clean and dry plastics and paper before recycling.\n"
            "- Hand over e-waste only to authorised collection centres.\n"
            "- Avoid single-use plastics and carry a cloth bag."
        ),
        "suggestions": [
            "Arrange regular collection and enforce door-to-door segregation.",
            "Provide separate green (wet), blue (dry) and red (hazardous) bins.",
            "Start community composting for food and organic waste.",
            "Penalise illegal dumping and burning of waste.",
        ],
    },
    "climate": {
        "keywords": ["climate", "global warming", "warming", "greenhouse", "carbon", "co2", "emission", "sea level"],
        "issue": "Climate Change",
        "answer": (
            "Climate change is the long-term shift in temperature and weather patterns, driven "
            "mainly by greenhouse gases (CO2, methane) from burning fossil fuels, deforestation "
            "and industry. Global warming leads to heat waves, floods, droughts, melting glaciers "
            "and rising sea levels.\n\n"
            "You can help by saving electricity, using renewable energy, eating more plant-based "
            "meals, wasting less food and planting trees."
        ),
        "suggestions": [
            "Switch to renewable energy (solar) and energy-efficient appliances.",
            "Reduce fossil-fuel travel; prefer public or electric transport.",
            "Protect and restore forests and wetlands that absorb carbon.",
        ],
    },
    "forest": {
        "keywords": ["forest", "tree", "deforest", "logging", "wildlife", "biodiversity"],
        "issue": "Deforestation",
        "answer": (
            "Deforestation is the large-scale removal of forests for farming, timber, mining and "
            "urban growth. It increases CO2 in the atmosphere, causes soil erosion and floods, and "
            "destroys wildlife habitats.\n\n"
            "Solutions: plant native trees, support afforestation drives, use recycled paper and "
            "certified wood, and report illegal tree cutting to the forest department."
        ),
        "suggestions": [
            "Report illegal tree cutting to the forest department immediately.",
            "Run compensatory plantation drives with native species.",
            "Use recycled paper and certified timber products.",
        ],
    },
    "recycle": {
        "keywords": ["recycl", "reuse", "plastic", "paper", "glass", "e-waste", "electronic"],
        "issue": "Recycling",
        "answer": (
            "Recycling turns used materials into new products and saves energy and raw materials.\n\n"
            "- Plastic: rinse, sort by type (PET, HDPE) and give to recyclers.\n"
            "- Paper: keep dry and clean; shredded paper can be composted.\n"
            "- Glass and metal: rinse and recycle endlessly without quality loss.\n"
            "- Electronics: donate working devices; recycle broken ones via e-waste centres."
        ),
        "suggestions": [
            "Rinse and sort recyclables before disposal.",
            "Choose products with recycled or minimal packaging.",
            "Repair and donate items before throwing them away.",
        ],
    },
    "energy": {
        "keywords": ["energy", "electric", "power", "solar", "saving", "bill"],
        "issue": "Energy Use",
        "answer": (
            "Saving energy cuts both your bills and emissions. Switch to LED bulbs, set the AC to "
            "24-26 C, unplug idle chargers, use 5-star rated appliances and consider rooftop solar."
        ),
        "suggestions": [
            "Replace old bulbs with LEDs and use natural light.",
            "Use 5-star appliances and switch off devices at the plug.",
            "Consider rooftop solar or a solar water heater.",
        ],
    },
}

GENERAL_ANSWER = (
    "I'm EcoSmart AI (demo mode). I can help with air pollution, water pollution, waste "
    "management, climate change, global warming, deforestation, recycling and ways to save "
    "energy and water. Try asking, for example: 'How can I reduce plastic waste?' or "
    "'What causes air pollution?'"
)


def _match_topic(text):
    """Return the knowledge-base entry whose keywords best match the text."""
    text = (text or "").lower()
    best, best_score = None, 0
    for entry in KNOWLEDGE.values():
        score = sum(1 for kw in entry["keywords"] if kw in text)
        if score > best_score:
            best, best_score = entry, score
    return best


# ---------------------------------------------------------------------------
# PUBLIC FUNCTIONS
# ---------------------------------------------------------------------------
def chat(history, user_message):
    """AI chatbot reply. `history` is a list of {"role","content"} dicts."""
    if not is_demo_mode():
        try:
            messages = [m for m in history if m["role"] in ("user", "assistant")]
            messages.append({"role": "user", "content": user_message})
            return {"reply": _ask_claude(messages, max_tokens=700), "demo": False}
        except Exception as exc:  # network / key / rate-limit problems
            print(f"[ai_service] Claude chat failed, using demo mode: {exc}")

    entry = _match_topic(user_message)
    return {"reply": entry["answer"] if entry else GENERAL_ANSWER, "demo": True}


def analyze_problem(description, category="", location=""):
    """Analyse an environmental problem description.

    Returns a dict: issue_type, severity, summary, causes[], suggestions[],
    health_impact, report (long text), demo (bool).
    """
    if not is_demo_mode():
        prompt = (
            "Analyse this environmental problem reported by a citizen.\n"
            f"Category: {category or 'not specified'}\nLocation: {location or 'not specified'}\n"
            f"Description: {description}\n\n"
            "Reply with ONLY valid JSON using exactly these keys: "
            '"issue_type" (string), "severity" ("Low"|"Medium"|"High"|"Critical"), '
            '"summary" (string, 2 sentences), "causes" (array of 3-4 strings), '
            '"health_impact" (string), "suggestions" (array of 4-5 actionable strings), '
            '"report" (a short formal environmental report of 120-180 words).'
        )
        try:
            raw = _ask_claude([{"role": "user", "content": prompt}], max_tokens=1200)
            match = re.search(r"\{.*\}", raw, re.DOTALL)
            data = json.loads(match.group(0))
            data["demo"] = False
            return data
        except Exception as exc:
            print(f"[ai_service] Claude analysis failed, using demo mode: {exc}")

    return _demo_analysis(description, category, location)


def _demo_analysis(description, category, location):
    entry = _match_topic(f"{category} {description}") or KNOWLEDGE["waste"]
    text = (description or "").lower()
    severity = "Medium"
    if any(w in text for w in ["toxic", "chemical", "hospital", "fish", "dead", "poison", "fire", "burning"]):
        severity = "Critical"
    elif any(w in text for w in ["large", "huge", "thick", "daily", "every", "spreading", "sewage", "smoke"]):
        severity = "High"
    elif len(text) < 60:
        severity = "Low"

    where = location or "the reported area"
    summary = (
        f"The description points to a {entry['issue'].lower()} problem at {where}. "
        f"The estimated severity is {severity.lower()} and it should be addressed by the responsible authority."
    )
    report = (
        f"ENVIRONMENTAL ANALYSIS REPORT\n\nIssue type: {entry['issue']}\nLocation: {where}\n"
        f"Severity: {severity}\n\nObservation: {description.strip()}\n\n"
        f"Assessment: {summary}\n\nRecommended actions:\n"
        + "\n".join(f"{i}. {s}" for i, s in enumerate(entry["suggestions"], 1))
        + "\n\n(Generated in demo mode.)"
    )
    return {
        "issue_type": entry["issue"],
        "severity": severity,
        "summary": summary,
        "causes": [
            "Lack of regular monitoring and enforcement",
            "Improper disposal or uncontrolled emissions",
            "Low public awareness of environmental rules",
        ],
        "health_impact": "Prolonged exposure can affect respiratory health, water safety and the local ecosystem.",
        "suggestions": entry["suggestions"],
        "report": report,
        "demo": True,
    }


def air_quality_advice(city, aqi, pm25, pm10):
    """Health + environmental advice for an AQI reading."""
    level = aqi_category(aqi)
    if not is_demo_mode():
        try:
            prompt = (
                f"Air quality in {city}: AQI {aqi} ({level['label']}), PM2.5 {pm25} ug/m3, "
                f"PM10 {pm10} ug/m3. Give 3 health tips and 3 environmental tips as short "
                "bullet points under the headings 'Health' and 'Environment'."
            )
            return {"advice": _ask_claude([{"role": "user", "content": prompt}], max_tokens=500), "demo": False}
        except Exception as exc:
            print(f"[ai_service] Claude air advice failed, using demo mode: {exc}")
    return {"advice": level["advice"], "demo": True}


def aqi_category(aqi):
    """Map AQI (India CPCB style bands) to a label, colour and demo advice."""
    bands = [
        (50, "Good", "#2e9e5b",
         "Health:\n- Air is clean; enjoy outdoor activities.\n\nEnvironment:\n- Keep it that way: walk, cycle or use public transport."),
        (100, "Satisfactory", "#8bc34a",
         "Health:\n- Very sensitive people should limit long outdoor exertion.\n\nEnvironment:\n- Avoid idling vehicles and open burning."),
        (200, "Moderate", "#f4b400",
         "Health:\n- People with asthma or heart disease should reduce outdoor activity.\n- Keep windows closed during peak traffic.\n\nEnvironment:\n- Carpool, avoid burning waste, sprinkle water on dust."),
        (300, "Poor", "#f57c00",
         "Health:\n- Wear an N95 mask outdoors.\n- Avoid morning/evening outdoor exercise.\n- Use an air purifier indoors if possible.\n\nEnvironment:\n- Avoid private vehicles; report open burning and construction dust."),
        (400, "Very Poor", "#e53935",
         "Health:\n- Stay indoors; children and elders must avoid going out.\n- Use N95 masks and air purifiers.\n\nEnvironment:\n- Support temporary restrictions on traffic, construction and industries."),
        (10_000, "Severe", "#8e24aa",
         "Health:\n- Health emergency: avoid all outdoor activity and seek medical help for breathing trouble.\n\nEnvironment:\n- Strictly stop burning, construction and heavy vehicles in the area."),
    ]
    for limit, label, color, advice in bands:
        if aqi <= limit:
            return {"label": label, "color": color, "advice": advice}


def personalized_recommendations(profile, focus="all"):
    """Personalised tips. `profile` holds city, counts and recent activity."""
    if not is_demo_mode():
        try:
            prompt = (
                "Create personalised environmental recommendations for this user.\n"
                f"Profile: {json.dumps(profile)}\nFocus area: {focus}\n\n"
                "Use headings: Reduce Pollution, Waste Recycling, Save Water, Save Energy. "
                "Give 3 specific bullet points under each heading (or only the focus area if not 'all')."
            )
            return {"content": _ask_claude([{"role": "user", "content": prompt}], max_tokens=900), "demo": False}
        except Exception as exc:
            print(f"[ai_service] Claude recommendations failed, using demo mode: {exc}")
    return {"content": _demo_recommendations(profile, focus), "demo": True}


def _demo_recommendations(profile, focus):
    city = profile.get("city") or "your city"
    sections = {
        "pollution": (
            "Reduce Pollution",
            [f"Use public transport or cycle for short trips in {city}.",
             "Never burn garbage, leaves or plastic.",
             "Plant at least one native tree this month."],
        ),
        "waste": (
            "Waste Recycling",
            ["Segregate waste into wet, dry and e-waste bins.",
             "Compost kitchen waste to make natural fertiliser.",
             "Give e-waste only to authorised recyclers."],
        ),
        "water": (
            "Save Water",
            ["Fix leaking taps - one drip can waste 20 litres a day.",
             "Reuse RO reject or washing water for plants and cleaning.",
             "Install rainwater harvesting where possible."],
        ),
        "energy": (
            "Save Energy",
            ["Switch to LED bulbs and 5-star appliances.",
             "Set the AC to 24-26 C and unplug idle chargers.",
             "Dry clothes in the sun instead of using a dryer."],
        ),
    }
    keys = list(sections) if focus in ("all", "", None) else [focus if focus in sections else "pollution"]
    parts = []
    for key in keys:
        title, tips = sections[key]
        parts.append(f"{title}\n" + "\n".join(f"- {t}" for t in tips))
    if profile.get("reports_count"):
        parts.append(
            f"Great work! You have submitted {profile['reports_count']} environmental report(s). "
            "Keep reporting problems in your neighbourhood."
        )
    return "\n\n".join(parts)
