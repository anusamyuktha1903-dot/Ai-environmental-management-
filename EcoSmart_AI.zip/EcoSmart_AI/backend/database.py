"""SQLite connection helpers, schema creation and demo data seeding.

Run `python database.py` to (re)create and seed the database.
"""
import os
import random
import sqlite3
from datetime import datetime, timedelta

from werkzeug.security import generate_password_hash

from config import Config


def get_connection():
    """Open a new SQLite connection with dict-like rows and FK enforcement."""
    os.makedirs(os.path.dirname(Config.DATABASE_PATH), exist_ok=True)
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def query(sql, params=(), one=False):
    """Run a SELECT and return rows as dicts (or a single dict / None)."""
    conn = get_connection()
    try:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()
    if one:
        return rows[0] if rows else None
    return rows


def execute(sql, params=()):
    """Run INSERT/UPDATE/DELETE, commit and return the last row id."""
    conn = get_connection()
    try:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    phone TEXT,
    city TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admin (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS environmental_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    location TEXT NOT NULL,
    image_path TEXT,
    status TEXT NOT NULL DEFAULT 'Pending',
    admin_remarks TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS air_quality_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    city TEXT NOT NULL,
    aqi INTEGER NOT NULL,
    pm25 REAL NOT NULL,
    pm10 REAL NOT NULL,
    no2 REAL,
    so2 REAL,
    co REAL,
    recorded_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS water_quality_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    location TEXT NOT NULL,
    source_type TEXT NOT NULL,
    ph REAL,
    turbidity REAL,
    tds REAL,
    dissolved_oxygen REAL,
    description TEXT,
    issues_detected TEXT,
    status TEXT NOT NULL DEFAULT 'Pending',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS waste_management (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    waste_type TEXT NOT NULL,
    quantity_kg REAL NOT NULL,
    location TEXT NOT NULL,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'Reported',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS chat_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ai_recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    input_text TEXT,
    content TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS complaints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Open',
    admin_response TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

CITIES = ["Chennai", "Delhi", "Mumbai", "Bengaluru", "Kolkata"]
# Typical base AQI per city, used to generate realistic demo readings
CITY_BASE_AQI = {"Chennai": 78, "Delhi": 210, "Mumbai": 112, "Bengaluru": 68, "Kolkata": 165}


def log_activity(actor, action):
    """Record an entry shown on the admin 'environmental activities' feed."""
    execute("INSERT INTO activity_log (actor, action) VALUES (?, ?)", (actor, action))


def init_db():
    """Create all tables."""
    conn = get_connection()
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()


def seed_demo_data():
    """Insert demo users, reports and 14 days of simulated sensor data (idempotent)."""
    if query("SELECT COUNT(*) AS c FROM admin", one=True)["c"] > 0:
        return  # already seeded

    random.seed(42)
    conn = get_connection()
    try:
        # --- Admin + demo users -------------------------------------------------
        conn.execute(
            "INSERT INTO admin (name, email, password_hash) VALUES (?,?,?)",
            ("Eco Admin", "admin@ecosmart.com", generate_password_hash("Admin@123")),
        )
        users = [
            ("Anu Samyuktha", "user@ecosmart.com", "User@123", "9876543210", "Chennai"),
            ("Ravi Kumar", "ravi@example.com", "Ravi@123", "9876500001", "Delhi"),
            ("Priya Nair", "priya@example.com", "Priya@123", "9876500002", "Bengaluru"),
            ("Arjun Mehta", "arjun@example.com", "Arjun@123", "9876500003", "Mumbai"),
        ]
        for name, email, pw, phone, city in users:
            conn.execute(
                "INSERT INTO users (name,email,password_hash,phone,city) VALUES (?,?,?,?,?)",
                (name, email, generate_password_hash(pw), phone, city),
            )

        # --- Air quality: 14 days x 5 cities ----------------------------------
        now = datetime.now()
        for day in range(13, -1, -1):
            ts = (now - timedelta(days=day)).strftime("%Y-%m-%d %H:%M:%S")
            for city in CITIES:
                aqi = max(20, int(CITY_BASE_AQI[city] + random.randint(-30, 35)))
                pm25 = round(aqi * random.uniform(0.35, 0.5), 1)
                pm10 = round(pm25 * random.uniform(1.4, 2.0), 1)
                conn.execute(
                    "INSERT INTO air_quality_data (city,aqi,pm25,pm10,no2,so2,co,recorded_at)"
                    " VALUES (?,?,?,?,?,?,?,?)",
                    (city, aqi, pm25, pm10,
                     round(random.uniform(15, 70), 1),
                     round(random.uniform(5, 30), 1),
                     round(random.uniform(0.4, 2.5), 2), ts),
                )

        # --- Environmental reports -------------------------------------------
        reports = [
            (1, "Garbage dumped near lake", "Waste Dumping",
             "Large pile of mixed garbage dumped on the lake shore, smell is spreading.",
             "Velachery, Chennai", "Pending"),
            (2, "Smoke from factory chimney", "Air Pollution",
             "Thick black smoke released every evening from an industrial unit.",
             "Okhla, Delhi", "In Progress"),
            (3, "Illegal tree cutting", "Deforestation",
             "About 20 trees were cut at the edge of the park without notice.",
             "Whitefield, Bengaluru", "Resolved"),
            (4, "Sewage entering stormwater drain", "Water Pollution",
             "Untreated sewage is flowing into the open drain near the market.",
             "Andheri, Mumbai", "Pending"),
            (1, "Loud construction noise at night", "Noise Pollution",
             "Construction work continues past midnight every day.",
             "Adyar, Chennai", "In Progress"),
            (2, "Plastic burning in open ground", "Air Pollution",
             "Residents burning plastic waste, toxic fumes in the neighbourhood.",
             "Dwarka, Delhi", "Resolved"),
        ]
        for i, (uid, title, cat, desc, loc, status) in enumerate(reports):
            created = (now - timedelta(days=12 - i * 2)).strftime("%Y-%m-%d %H:%M:%S")
            conn.execute(
                "INSERT INTO environmental_reports (user_id,title,category,description,"
                "location,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)",
                (uid, title, cat, desc, loc, status, created, created),
            )

        # --- Water quality reports -------------------------------------------
        waters = [
            (1, "Adyar River, Chennai", "River", 6.1, 18.0, 640, 4.2,
             "Foul smell and dark colour near the bridge.",
             "Low pH (acidic); High turbidity; High TDS; Low dissolved oxygen"),
            (3, "Ulsoor Lake, Bengaluru", "Lake", 7.4, 4.0, 310, 6.8,
             "Water looks fairly clear.", "No major issues detected"),
            (4, "Mithi River, Mumbai", "River", 7.9, 22.0, 820, 3.1,
             "Floating waste and oil film.", "High turbidity; High TDS; Low dissolved oxygen"),
        ]
        for i, (uid, loc, src, ph, turb, tds, do, desc, issues) in enumerate(waters):
            created = (now - timedelta(days=9 - i * 3)).strftime("%Y-%m-%d %H:%M:%S")
            conn.execute(
                "INSERT INTO water_quality_reports (user_id,location,source_type,ph,turbidity,"
                "tds,dissolved_oxygen,description,issues_detected,status,created_at)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (uid, loc, src, ph, turb, tds, do, desc, issues,
                 "Reviewed" if i == 1 else "Pending", created),
            )

        # --- Waste collection reports ----------------------------------------
        waste_types = ["Plastic Waste", "Paper Waste", "Food Waste", "Electronic Waste", "Organic Waste"]
        statuses = ["Reported", "Scheduled", "Collected"]
        for i in range(18):
            created = (now - timedelta(days=random.randint(0, 13))).strftime("%Y-%m-%d %H:%M:%S")
            conn.execute(
                "INSERT INTO waste_management (user_id,waste_type,quantity_kg,location,notes,status,created_at)"
                " VALUES (?,?,?,?,?,?,?)",
                (random.randint(1, 4), random.choice(waste_types),
                 round(random.uniform(1, 25), 1),
                 random.choice(["T. Nagar, Chennai", "Karol Bagh, Delhi", "Indiranagar, Bengaluru",
                                "Bandra, Mumbai", "Salt Lake, Kolkata"]),
                 "Demo collection request", random.choice(statuses), created),
            )

        # --- Complaints ------------------------------------------------------
        conn.execute(
            "INSERT INTO complaints (user_id,subject,message,status) VALUES (?,?,?,?)",
            (1, "Garbage not collected", "Waste has not been collected in my street for 5 days.", "Open"),
        )
        conn.execute(
            "INSERT INTO complaints (user_id,subject,message,status,admin_response) VALUES (?,?,?,?,?)",
            (2, "Broken air monitor", "The air monitor near my area shows no data.", "Resolved",
             "Sensor has been repaired. Thank you for reporting."),
        )

        # --- Activity feed -----------------------------------------------------
        for actor, action in [
            ("Anu Samyuktha", "submitted report 'Garbage dumped near lake'"),
            ("Ravi Kumar", "submitted report 'Smoke from factory chimney'"),
            ("Eco Admin", "marked report 'Illegal tree cutting' as Resolved"),
            ("Priya Nair", "submitted a water quality report for Ulsoor Lake"),
        ]:
            conn.execute("INSERT INTO activity_log (actor, action) VALUES (?,?)", (actor, action))

        conn.commit()
    finally:
        conn.close()


def setup():
    """Create tables and seed demo data."""
    init_db()
    seed_demo_data()


if __name__ == "__main__":
    setup()
    print(f"Database ready at: {Config.DATABASE_PATH}")
