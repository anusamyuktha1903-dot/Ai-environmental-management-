"""Small input-validation helpers used by the route modules."""
import re

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class ValidationError(Exception):
    """Raised when user input is invalid; message is shown to the user."""


def clean_text(value, field, min_len=1, max_len=1000, required=True):
    value = (value or "").strip() if isinstance(value, str) or value is None else str(value).strip()
    if not value:
        if required:
            raise ValidationError(f"{field} is required.")
        return ""
    if len(value) < min_len:
        raise ValidationError(f"{field} must be at least {min_len} characters.")
    if len(value) > max_len:
        raise ValidationError(f"{field} must be at most {max_len} characters.")
    return value


def valid_email(value):
    value = clean_text(value, "Email", max_len=120).lower()
    if not EMAIL_RE.match(value):
        raise ValidationError("Please enter a valid email address.")
    return value


def valid_password(value):
    if not isinstance(value, str) or len(value) < 6:
        raise ValidationError("Password must be at least 6 characters.")
    return value


def optional_float(value, field, minimum=None, maximum=None):
    """Parse an optional numeric field (empty -> None)."""
    if value in (None, ""):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{field} must be a number.")
    if minimum is not None and number < minimum:
        raise ValidationError(f"{field} must be at least {minimum}.")
    if maximum is not None and number > maximum:
        raise ValidationError(f"{field} must be at most {maximum}.")
    return number


def one_of(value, field, options):
    if value not in options:
        raise ValidationError(f"{field} must be one of: {', '.join(options)}.")
    return value
