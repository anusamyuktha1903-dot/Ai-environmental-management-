"""Token creation / verification and route decorators.

Tokens are signed with itsdangerous (bundled with Flask). The token holds the
account id and role ("user" or "admin") and is sent by the frontend in the
`Authorization: Bearer <token>` header.
"""
from functools import wraps

from flask import g, jsonify, request
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from config import Config
from database import query


def _serializer():
    return URLSafeTimedSerializer(Config.SECRET_KEY, salt="ecosmart-auth")


def create_token(account_id, role):
    return _serializer().dumps({"id": account_id, "role": role})


def _load_current_account():
    """Return the account dict for the request's bearer token, or None."""
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    try:
        data = _serializer().loads(header[7:], max_age=Config.TOKEN_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None

    table = "admin" if data.get("role") == "admin" else "users"
    account = query(f"SELECT * FROM {table} WHERE id = ?", (data.get("id"),), one=True)
    if not account:
        return None
    account["role"] = data["role"]
    return account


def login_required(fn):
    """Allow any logged-in user or admin."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        account = _load_current_account()
        if not account:
            return jsonify({"error": "Authentication required. Please log in."}), 401
        g.account = account
        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    """Allow only administrators."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        account = _load_current_account()
        if not account:
            return jsonify({"error": "Authentication required. Please log in."}), 401
        if account["role"] != "admin":
            return jsonify({"error": "Administrator access required."}), 403
        g.account = account
        return fn(*args, **kwargs)
    return wrapper


def public_account(account):
    """Strip secrets before returning an account to the frontend."""
    return {k: v for k, v in account.items() if k != "password_hash"}
