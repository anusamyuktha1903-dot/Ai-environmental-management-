"""Data-model helpers: authentication utilities and input validators."""
