"""Central configuration for the EcoSmart AI backend.

All secrets are read from environment variables (loaded from backend/.env).
Nothing sensitive is ever sent to the frontend.
"""
import os
from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))

# Load backend/.env if present
load_dotenv(os.path.join(BASE_DIR, ".env"))


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
    TOKEN_MAX_AGE = 60 * 60 * 24 * 7  # login tokens valid for 7 days

    # SQLite database lives in /database/ecosmart.db (see project structure)
    DATABASE_PATH = os.getenv(
        "DATABASE_PATH", os.path.join(PROJECT_ROOT, "database", "ecosmart.db")
    )

    # Uploaded environmental issue images
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # 5 MB
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

    # Claude / Anthropic
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
    CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")

    # Code needed to register as admin (prevents anyone from becoming admin)
    ADMIN_REGISTRATION_CODE = os.getenv("ADMIN_REGISTRATION_CODE", "ECOADMIN2026")

    CORS_ORIGINS = os.getenv(
        "CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
    ).split(",")
