import { Navigate, Route, Routes } from "react-router-dom";

import PublicLayout from "./components/PublicLayout";
import DashboardLayout from "./components/DashboardLayout";
import ProtectedRoute from "./components/ProtectedRoute";

import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Login from "./pages/Login";
import Register from "./pages/Register";
import UserDashboard from "./pages/UserDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import AdminUsers from "./pages/AdminUsers";
import AdminComplaints from "./pages/AdminComplaints";
import AIAnalysis from "./pages/AIAnalysis";
import AirQuality from "./pages/AirQuality";
import Water from "./pages/Water";
import Waste from "./pages/Waste";
import Reports from "./pages/Reports";
import Chatbot from "./pages/Chatbot";
import Statistics from "./pages/Statistics";
import Recommendations from "./pages/Recommendations";
import Complaints from "./pages/Complaints";
import Profile from "./pages/Profile";

export default function App() {
  return (
    <Routes>
      {/* Public pages */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
      </Route>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Logged-in pages (sidebar layout) */}
      <Route element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
        <Route path="/dashboard" element={<ProtectedRoute role="user"><UserDashboard /></ProtectedRoute>} />
        <Route path="/admin" element={<ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/users" element={<ProtectedRoute role="admin"><AdminUsers /></ProtectedRoute>} />
        <Route path="/admin/complaints" element={<ProtectedRoute role="admin"><AdminComplaints /></ProtectedRoute>} />
        <Route path="/analysis" element={<AIAnalysis />} />
        <Route path="/air-quality" element={<AirQuality />} />
        <Route path="/water" element={<Water />} />
        <Route path="/waste" element={<Waste />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/chatbot" element={<Chatbot />} />
        <Route path="/statistics" element={<Statistics />} />
        <Route path="/recommendations" element={<ProtectedRoute role="user"><Recommendations /></ProtectedRoute>} />
        <Route path="/complaints" element={<ProtectedRoute role="user"><Complaints /></ProtectedRoute>} />
        <Route path="/profile" element={<Profile />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
