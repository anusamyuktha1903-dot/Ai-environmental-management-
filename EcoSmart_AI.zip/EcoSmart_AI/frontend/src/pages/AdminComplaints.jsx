import { useState } from "react";
import { api } from "../services/api";
import { useFetch } from "../services/hooks";
import { Alert, Card, EmptyState, PageHeader, Spinner, StatusBadge, fmtDate } from "../components/UI";

export default function AdminComplaints() {
  const { data, loading, error, reload } = useFetch("/api/admin/complaints");
  const [editing, setEditing] = useState(null); // complaint being answered
  const [form, setForm] = useState({ status: "In Progress", admin_response: "" });
  const [msg, setMsg] = useState({ type: "", text: "" });

  function open(c) {
    setEditing(c);
    setForm({ status: c.status === "Open" ? "In Progress" : c.status, admin_response: c.admin_response || "" });
  }

  async function save() {
    try {
      await api.put(`/api/admin/complaints/${editing.id}`, form);
      setMsg({ type: "success", text: "Complaint updated." });
      setEditing(null);
      reload();
    } catch (e) {
      setMsg({ type: "danger", text: e.message });
    }
  }

  if (loading) return <Spinner />;
  const list = data?.complaints || [];
  const statuses = data?.statuses || [];

  return (
    <>
      <PageHeader title="User Complaints" subtitle="Review complaints, respond and update their status" />
      <Alert>{error}</Alert>
      <Alert type={msg.type || "info"} onClose={() => setMsg({ type: "", text: "" })}>{msg.text}</Alert>

      {editing && (
        <Card title={`Respond to: ${editing.subject}`} className="mb-3">
          <p className="text-muted">{editing.message}</p>
          <div className="row g-3">
            <div className="col-md-3">
              <label className="form-label">Status</label>
              <select className="form-select" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                {statuses.map((s) => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="col-md-9">
              <label className="form-label">Response to user</label>
              <input className="form-control" value={form.admin_response} maxLength={500}
                     onChange={(e) => setForm({ ...form, admin_response: e.target.value })} />
            </div>
          </div>
          <div className="mt-3 d-flex gap-2">
            <button className="btn btn-primary" onClick={save}>Save</button>
            <button className="btn btn-outline-secondary" onClick={() => setEditing(null)}>Cancel</button>
          </div>
        </Card>
      )}

      <Card pad={false}>
        {list.length === 0 ? <EmptyState icon="envelope-check" text="No complaints" /> : (
          <div className="table-responsive">
            <table className="table table-eco table-hover mb-0">
              <thead><tr><th>User</th><th>Subject</th><th>Message</th><th>Status</th><th>Date</th><th></th></tr></thead>
              <tbody>
                {list.map((c) => (
                  <tr key={c.id}>
                    <td>{c.user_name}<div className="small text-muted">{c.user_email}</div></td>
                    <td className="fw-semibold">{c.subject}</td>
                    <td style={{ maxWidth: 320 }}>{c.message}{c.admin_response && <div className="small text-success mt-1"><i className="bi bi-reply me-1"></i>{c.admin_response}</div>}</td>
                    <td><StatusBadge status={c.status} /></td>
                    <td className="text-muted">{fmtDate(c.created_at)}</td>
                    <td className="text-end"><button className="btn btn-outline-primary btn-sm" onClick={() => open(c)}>Respond</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
