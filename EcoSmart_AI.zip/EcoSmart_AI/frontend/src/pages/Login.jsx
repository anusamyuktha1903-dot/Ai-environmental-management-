import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../services/AuthContext";
import { Alert } from "../components/UI";

// Demo accounts created by the seed data (also listed in README)
const DEMO = {
  user: { email: "user@ecosmart.com", password: "User@123" },
  admin: { email: "admin@ecosmart.com", password: "Admin@123" },
};

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState("user");
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to={user.role === "admin" ? "/admin" : "/dashboard"} replace />;

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (!form.email || !form.password) return setError("Please enter your email and password.");
    setBusy(true);
    try {
      const u = await login(form.email, form.password, role);
      navigate(u.role === "admin" ? "/admin" : "/dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-side">
        <Link to="/" className="text-white text-decoration-none fs-4 fw-bold mb-4">
          <i className="bi bi-tree-fill me-2"></i>EcoSmart AI
        </Link>
        <h1 className="fw-bold">Welcome back</h1>
        <p className="fs-5 opacity-75">Sign in to monitor the environment, report problems and get AI-powered recommendations.</p>
        <ul className="list-unstyled mt-3 opacity-75">
          <li className="mb-2"><i className="bi bi-check-circle me-2"></i>Live air quality dashboards</li>
          <li className="mb-2"><i className="bi bi-check-circle me-2"></i>AI environmental assistant</li>
          <li><i className="bi bi-check-circle me-2"></i>Track your reports and complaints</li>
        </ul>
      </div>
      <div className="auth-form">
        <div className="auth-card">
          <h3 className="fw-bold mb-1">Login</h3>
          <p className="text-muted mb-4">Choose your account type and sign in.</p>

          <div className="btn-group w-100 mb-4" role="group">
            <button type="button" className={`btn ${role === "user" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setRole("user")}>
              <i className="bi bi-person me-1"></i>User
            </button>
            <button type="button" className={`btn ${role === "admin" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setRole("admin")}>
              <i className="bi bi-shield-lock me-1"></i>Admin
            </button>
          </div>

          <Alert onClose={() => setError("")}>{error}</Alert>

          <form onSubmit={submit} noValidate>
            <div className="mb-3">
              <label className="form-label">Email</label>
              <input className="form-control form-control-lg" type="email" autoComplete="username"
                     value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
            </div>
            <div className="mb-3">
              <label className="form-label">Password</label>
              <input className="form-control form-control-lg" type="password" autoComplete="current-password"
                     value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Your password" />
            </div>
            <button className="btn btn-primary btn-lg w-100" disabled={busy}>
              {busy ? "Signing in..." : "Login"}
            </button>
          </form>

          <button type="button" className="btn btn-link w-100 mt-2 text-decoration-none"
                  onClick={() => setForm(DEMO[role])}>
            <i className="bi bi-magic me-1"></i>Fill demo {role} credentials
          </button>

          <p className="text-center text-muted mt-3 mb-0">
            New here? <Link to="/register">Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
