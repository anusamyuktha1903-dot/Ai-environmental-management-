import { useEffect, useRef, useState } from "react";
import { api } from "../services/api";
import { useFetch } from "../services/hooks";
import { AiBadge, Alert, PageHeader } from "../components/UI";

const SUGGESTIONS = [
  "What causes air pollution?",
  "How can I reduce plastic waste?",
  "Explain global warming simply",
  "Why is deforestation a problem?",
  "How do I recycle e-waste?",
  "Tips to save water at home",
];

export default function Chatbot() {
  const status = useFetch("/api/ai/status");
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [demo, setDemo] = useState(null);
  const endRef = useRef(null);

  // Load the saved conversation once
  useEffect(() => {
    api.get("/api/ai/chat/history")
      .then((d) => setMessages(d.messages.map((m) => ({ role: m.role, text: m.message }))))
      .catch((e) => setError(e.message));
  }, []);

  // Always scroll to the newest message
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  async function send(content) {
    const message = (content ?? text).trim();
    if (!message || busy) return;
    setError("");
    setText("");
    setMessages((m) => [...m, { role: "user", text: message }]);
    setBusy(true);
    try {
      const d = await api.post("/api/ai/chat", { message });
      setDemo(d.demo);
      setMessages((m) => [...m, { role: "assistant", text: d.reply }]);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function clearChat() {
    if (!window.confirm("Clear the whole conversation?")) return;
    try {
      await api.del("/api/ai/chat/history");
      setMessages([]);
    } catch (err) {
      setError(err.message);
    }
  }

  const isDemo = demo ?? status.data?.demo_mode ?? true;

  return (
    <>
      <PageHeader title="AI Environmental Assistant" subtitle="Ask about air and water pollution, waste, climate change, recycling and more">
        <AiBadge demo={isDemo} />
        <button className="btn btn-outline-danger btn-sm" onClick={clearChat} disabled={!messages.length}>
          <i className="bi bi-trash me-1"></i>Clear chat
        </button>
      </PageHeader>
      <Alert onClose={() => setError("")}>{error}</Alert>

      <div className="eco-card card-pad">
        <div className="chat-box">
          {messages.length === 0 && (
            <div className="text-center text-muted py-4">
              <i className="bi bi-chat-heart fs-1 text-primary"></i>
              <div className="mt-2 mb-3">Hi! I'm EcoSmart AI. Try one of these questions:</div>
              <div className="d-flex flex-wrap justify-content-center gap-2">
                {SUGGESTIONS.map((s) => (
                  <button key={s} className="btn btn-outline-primary btn-sm" onClick={() => send(s)}>{s}</button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`bubble ${m.role}`}>{m.text}</div>
          ))}
          {busy && <div className="bubble assistant typing"><span></span><span></span><span></span></div>}
          <div ref={endRef}></div>
        </div>

        <form className="d-flex gap-2 mt-3" onSubmit={(e) => { e.preventDefault(); send(); }}>
          <input className="form-control form-control-lg" placeholder="Ask an environmental question..." value={text}
                 maxLength={1000} onChange={(e) => setText(e.target.value)} />
          <button className="btn btn-primary btn-lg" disabled={busy || !text.trim()}><i className="bi bi-send"></i></button>
        </form>
      </div>
    </>
  );
}
