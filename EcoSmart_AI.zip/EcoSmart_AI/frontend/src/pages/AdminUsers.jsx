import { useState } from "react";
import { api } from "../services/api";
import { useFetch } from "../services/hooks";
import { Alert, Card, EmptyState, PageHeader, Spinner, fmtDate } from "../components/UI";

export default function AdminUsers() {
  const { data, loading, error, reload } = useFetch("/api/admin/users");
  const [msg, setMsg] = useState({ type: "", text: "" });

  async function remove(u) {
    if (!window.confirm(`Remove user "${u.name}" and all of their data?`)) return;
    try {
      await api.del(`/api/admin/users/${u.id}`);
      setMsg({ type: "success", text: "User removed." });
      reload();
    } catch (e) {
      setMsg({ type: "danger", text: e.message });
    }
  }

  if (loading) return <Spinner />;
  const users = data?.users || [];

  return (
    <>
      <PageHeader title="Users" subtitle={`${users.length} registered users`} />
      <Alert>{error}</Alert>
      <Alert type={msg.type || "info"} onClose={() => setMsg({ type: "", text: "" })}>{msg.text}</Alert>
      <Card pad={false}>
        {users.length === 0 ? <EmptyState icon="people" text="No users yet" /> : (
          <div className="table-responsive">
            <table className="table table-eco table-hover mb-0">
              <thead><tr><th>Name</th><th>Email</th><th>City</th><th>Phone</th><th>Reports</th><th>Joined</th><th></th></tr></thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="fw-semibold">{u.name}</td><td>{u.email}</td><td>{u.city || "-"}</td>
                    <td>{u.phone || "-"}</td><td>{u.reports}</td><td className="text-muted">{fmtDate(u.created_at)}</td>
                    <td className="text-end">
                      <button className="btn btn-outline-danger btn-sm" onClick={() => remove(u)}><i className="bi bi-trash"></i></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
