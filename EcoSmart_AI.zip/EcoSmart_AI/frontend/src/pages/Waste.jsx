import { useState } from "react";
import { Doughnut, Bar } from "react-chartjs-2";
import { api } from "../services/api";
import { useAuth } from "../services/AuthContext";
import { useFetch } from "../services/hooks";
import { PALETTE } from "../services/chartSetup";
import { Alert, Card, EmptyState, PageHeader, Spinner, StatusBadge, fmtDate } from "../components/UI";

const ICONS = {
  "Plastic Waste": "cup-straw", "Paper Waste": "file-earmark-text", "Food Waste": "egg-fried",
  "Electronic Waste": "cpu", "Organic Waste": "flower1",
};

export default function Waste() {
  const { user } = useAuth();
  const isAdmin = user.role === "admin";
  const guide = useFetch("/api/waste/guide");
  const stats = useFetch("/api/waste/stats");
  const list = useFetch("/api/waste");
  const [form, setForm] = useState({ waste_type: "Plastic Waste", quantity_kg: "", location: "", notes: "" });
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [tip, setTip] = useState(null);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState("Plastic Waste");

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const types = guide.data?.types || [];
  const info = guide.data?.guide?.[selected];

  function reloadAll() {
    list.reload();
    stats.reload();
  }

  async function submit(e) {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (!form.quantity_kg || Number(form.quantity_kg) <= 0) return setMsg({ type: "danger", text: "Enter a valid quantity in kg." });
    if (form.location.trim().length < 3) return setMsg({ type: "danger", text: "Please enter the location." });
    setBusy(true);
    try {
      const d = await api.post("/api/waste", form);
      setTip({ type: form.waste_type, ...d.guide });
      setMsg({ type: "success", text: "Waste collection report submitted." });
      setForm({ ...form, quantity_kg: "", notes: "" });
      reloadAll();
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function setStatus(id, status) {
    try {
      await api.put(`/api/waste/${id}`, { status });
      reloadAll();
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    }
  }

  if (guide.loading) return <Spinner />;
  const byType = stats.data?.by_type || [];
  const reports = list.data?.reports || [];

  return (
    <>
      <PageHeader title={isAdmin ? "Waste Collection Reports" : "Waste Management"}
                  subtitle="Categorise waste, learn how to segregate and recycle, and track collection reports" />
      <Alert type={msg.type || "info"} onClose={() => setMsg({ type: "", text: "" })}>{msg.text}</Alert>

      {/* Category selector + segregation / recycling guide */}
      <div className="row g-2 mb-3">
        {types.map((t) => (
          <div className="col-6 col-md-4 col-xl" key={t}>
            <div className={`city-pill text-center ${selected === t ? "active" : ""}`} role="button" onClick={() => setSelected(t)}>
              <i className={`bi bi-${ICONS[t]} fs-3 text-primary`}></i>
              <div className="fw-semibold small mt-1">{t}</div>
            </div>
          </div>
        ))}
      </div>
      {info && (
        <Card title={<><i className={`bi bi-${ICONS[selected]} text-primary me-2`}></i>{selected} guide</>} className="mb-3">
          <div className="row g-3">
            <div className="col-md-3"><div className="stat-label">Which bin</div><div className="fw-semibold">{info.bin}</div><div className="small text-muted mt-1">e.g. {info.examples}</div></div>
            <div className="col-md-4"><div className="stat-label"><i className="bi bi-funnel me-1"></i>Segregation suggestion</div><div>{info.segregation}</div></div>
            <div className="col-md-5"><div className="stat-label"><i className="bi bi-recycle me-1"></i>Recycling recommendation</div><div>{info.recycling}</div></div>
          </div>
        </Card>
      )}

      <div className="row g-3 mb-3">
        {!isAdmin && (
          <div className="col-lg-4">
            <Card title="Report waste for collection">
              <form onSubmit={submit} noValidate>
                <div className="mb-3">
                  <label className="form-label">Waste type</label>
                  <select className="form-select" name="waste_type" value={form.waste_type} onChange={change}>
                    {types.map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className="mb-3"><label className="form-label">Quantity (kg)</label><input className="form-control" type="number" step="0.1" min="0" name="quantity_kg" value={form.quantity_kg} onChange={change} /></div>
                <div className="mb-3"><label className="form-label">Location</label><input className="form-control" name="location" value={form.location} onChange={change} placeholder="Street / area" /></div>
                <div className="mb-3"><label className="form-label">Notes <span className="text-muted">(optional)</span></label><textarea className="form-control" rows="2" name="notes" value={form.notes} onChange={change} /></div>
                <button className="btn btn-primary w-100" disabled={busy}>{busy ? "Submitting..." : "Submit"}</button>
              </form>
              {tip && (
                <div className="alert alert-success mt-3 mb-0 small">
                  <strong>Tip for {tip.type}:</strong> {tip.segregation} <br /><strong>Recycle:</strong> {tip.recycling}
                </div>
              )}
            </Card>
          </div>
        )}
        <div className={isAdmin ? "col-lg-6" : "col-lg-4"}>
          <Card title="Waste by type (kg)">
            {byType.length === 0 ? <EmptyState icon="recycle" text="No data yet" /> : (
              <div className="chart-box-sm">
                <Doughnut data={{ labels: byType.map((r) => r.waste_type), datasets: [{ data: byType.map((r) => r.total_kg), backgroundColor: PALETTE }] }}
                          options={{ maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }} />
              </div>
            )}
          </Card>
        </div>
        <div className={isAdmin ? "col-lg-6" : "col-lg-4"}>
          <Card title="Collection status">
            {(stats.data?.by_status || []).length === 0 ? <EmptyState icon="truck" text="No data yet" /> : (
              <div className="chart-box-sm">
                <Bar data={{ labels: stats.data.by_status.map((s) => s.status), datasets: [{ label: "Reports", data: stats.data.by_status.map((s) => s.count), backgroundColor: ["#f4b400", "#26a69a", "#1f8a4c"], borderRadius: 6 }] }}
                     options={{ maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { ticks: { precision: 0 } } } }} />
              </div>
            )}
          </Card>
        </div>
      </div>

      <Card title={isAdmin ? "All waste collection reports" : "My waste collection reports"} pad={false}>
        {list.loading ? <Spinner /> : reports.length === 0 ? <EmptyState icon="truck" text="No waste reports yet." /> : (
          <div className="table-responsive">
            <table className="table table-eco table-hover mb-0">
              <thead><tr>{isAdmin && <th>User</th>}<th>Type</th><th>Quantity</th><th>Location</th><th>Status</th><th>Date</th></tr></thead>
              <tbody>
                {reports.map((r) => (
                  <tr key={r.id}>
                    {isAdmin && <td>{r.user_name}</td>}
                    <td><i className={`bi bi-${ICONS[r.waste_type]} text-primary me-2`}></i>{r.waste_type}</td>
                    <td>{r.quantity_kg} kg</td><td>{r.location}</td>
                    <td>
                      {isAdmin ? (
                        <select className="form-select form-select-sm" value={r.status} onChange={(e) => setStatus(r.id, e.target.value)}>
                          {["Reported", "Scheduled", "Collected"].map((s) => <option key={s}>{s}</option>)}
                        </select>
                      ) : <StatusBadge status={r.status} />}
                    </td>
                    <td className="text-muted">{fmtDate(r.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
