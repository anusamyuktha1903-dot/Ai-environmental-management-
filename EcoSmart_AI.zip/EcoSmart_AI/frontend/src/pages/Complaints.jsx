import { useState } from "react";
import { api } from "../services/api";
import { useFetch } from "../services/hooks";
import { Alert, Card, EmptyState, PageHeader, Spinner, StatusBadge, fmtDate } from "../components/UI";

export default function Complaints() {
  const { data, loading, reload } = useFetch("/api/complaints");
  const [form, setForm] = useState({ subject: "", message: "" });
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (form.subject.trim().length < 4) return setMsg({ type: "danger", text: "Subject must be at least 4 characters." });
    if (form.message.trim().length < 10) return setMsg({ type: "danger", text: "Message must be at least 10 characters." });
    setBusy(true);
    try {
      await api.post("/api/complaints", form);
      setMsg({ type: "success", text: "Complaint submitted. You can track its status below." });
      setForm({ subject: "", message: "" });
      reload();
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  const list = data?.complaints || [];

  return (
    <>
      <PageHeader title="My Complaints" subtitle="Submit a complaint and track how the administrators respond" />
      <Alert type={msg.type || "info"} onClose={() => setMsg({ type: "", text: "" })}>{msg.text}</Alert>
      <div className="row g-3">
        <div className="col-lg-4">
          <Card title="Submit a complaint">
            <form onSubmit={submit} noValidate>
              <div className="mb-3"><label className="form-label">Subject</label><input className="form-control" value={form.subject} maxLength={120} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></div>
              <div className="mb-3"><label className="form-label">Message</label><textarea className="form-control" rows="5" value={form.message} maxLength={1500} onChange={(e) => setForm({ ...form, message: e.target.value })} /></div>
              <button className="btn btn-primary w-100" disabled={busy}>{busy ? "Submitting..." : "Submit complaint"}</button>
            </form>
          </Card>
        </div>
        <div className="col-lg-8">
          <Card title="Complaint status" pad={false}>
            {loading ? <Spinner /> : list.length === 0 ? <EmptyState icon="envelope-check" text="You have not submitted any complaints." /> : (
              <div className="list-group list-group-flush">
                {list.map((c) => (
                  <div className="list-group-item p-3" key={c.id}>
                    <div className="d-flex justify-content-between align-items-start gap-2">
                      <strong>{c.subject}</strong><StatusBadge status={c.status} />
                    </div>
                    <div className="text-muted small mb-1">{fmtDate(c.created_at)}</div>
                    <div>{c.message}</div>
                    {c.admin_response && <div className="alert alert-success py-2 mt-2 mb-0 small"><i className="bi bi-reply me-1"></i><strong>Admin response:</strong> {c.admin_response}</div>}
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
