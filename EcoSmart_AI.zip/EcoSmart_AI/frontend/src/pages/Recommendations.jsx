import { useState } from "react";
import { api } from "../services/api";
import { useFetch } from "../services/hooks";
import { AiBadge, Alert, Card, EmptyState, PageHeader, fmtDate } from "../components/UI";

const FOCUS = [
  ["all", "All areas", "stars"],
  ["pollution", "Reduce pollution", "wind"],
  ["waste", "Recycle waste", "recycle"],
  ["water", "Save water", "droplet-half"],
  ["energy", "Save energy", "lightning-charge"],
];

export default function Recommendations() {
  const history = useFetch("/api/ai/recommendations/history");
  const [focus, setFocus] = useState("all");
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    setBusy(true);
    setError("");
    try {
      setResult(await api.post("/api/ai/recommendations", { focus }));
      history.reload();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  const past = (history.data?.items || []).filter((i) => i.kind.startsWith("recommendation"));

  return (
    <>
      <PageHeader title="AI Recommendations" subtitle="Personalised tips to reduce pollution, recycle waste, save water and save energy" />
      <Alert onClose={() => setError("")}>{error}</Alert>

      <div className="row g-3">
        <div className="col-lg-7">
          <Card title="Generate my recommendations" right={result && <AiBadge demo={result.demo} />}>
            <div className="d-flex flex-wrap gap-2 mb-3">
              {FOCUS.map(([key, label, icon]) => (
                <button key={key} className={`btn btn-sm ${focus === key ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setFocus(key)}>
                  <i className={`bi bi-${icon} me-1`}></i>{label}
                </button>
              ))}
            </div>
            <button className="btn btn-primary mb-3" onClick={generate} disabled={busy}>
              {busy ? <><span className="spinner-border spinner-border-sm me-2"></span>Generating...</> : <><i className="bi bi-stars me-1"></i>Generate recommendations</>}
            </button>
            {result ? <div className="ai-output">{result.content}</div>
              : <div className="text-muted">Pick a focus area and click generate. Tips are personalised using your city, your reports and your waste activity.</div>}
          </Card>
        </div>
        <div className="col-lg-5">
          <Card title="Previous recommendations" pad={false}>
            {past.length === 0 ? <EmptyState icon="lightbulb" text="Nothing generated yet." /> : (
              <div className="list-group list-group-flush" style={{ maxHeight: 520, overflowY: "auto" }}>
                {past.map((p) => (
                  <button key={p.id} className="list-group-item list-group-item-action" onClick={() => setResult({ content: p.content, demo: false })}>
                    <div className="d-flex justify-content-between">
                      <strong className="text-capitalize">{p.kind.split(":")[1]}</strong>
                      <small className="text-muted">{fmtDate(p.created_at)}</small>
                    </div>
                    <div className="small text-muted text-truncate">{p.content.replace(/\n+/g, " ")}</div>
                  </button>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
