import { Link } from "react-router-dom";
import { useFetch } from "../services/hooks";
import { useAuth } from "../services/AuthContext";

const FEATURES = [
  ["cpu", "AI Environmental Analysis", "Describe a problem and Claude AI identifies the issue, severity, causes and solutions."],
  ["wind", "Air Quality Monitoring", "Track AQI, PM2.5 and PM10 for major cities with charts and health advice."],
  ["droplet-half", "Water Quality Management", "Record water tests, detect pollution issues and learn to conserve water."],
  ["recycle", "Waste Management", "Segregate plastic, paper, food, e-waste and organic waste with recycling tips."],
  ["flag", "Smart Reporting", "Report problems with photos and location and track their status."],
  ["chat-dots", "AI Chatbot", "Ask anything about climate change, pollution, recycling and more."],
];

export default function Home() {
  const { user } = useAuth();
  const { data } = useFetch("/api/air/current");
  const readings = data?.readings || [];

  return (
    <>
      <section className="hero">
        <div className="container">
          <div className="row align-items-center g-5">
            <div className="col-lg-7">
              <span className="badge bg-light text-success mb-3 px-3 py-2">
                <i className="bi bi-stars me-1"></i>AI-Centered Environmental Management
              </span>
              <h1 className="display-4">Protect the planet with the power of AI</h1>
              <p className="lead mt-3">
                EcoSmart AI helps you monitor air and water quality, manage waste, report
                environmental problems and get smart, personalised recommendations - all in one place.
              </p>
              <div className="d-flex flex-wrap gap-2 mt-4">
                {user ? (
                  <Link to={user.role === "admin" ? "/admin" : "/dashboard"} className="btn btn-light btn-lg text-success fw-semibold">
                    Go to Dashboard
                  </Link>
                ) : (
                  <>
                    <Link to="/register" className="btn btn-light btn-lg text-success fw-semibold">Get Started</Link>
                    <Link to="/login" className="btn btn-outline-light btn-lg">Login</Link>
                  </>
                )}
              </div>
            </div>
            <div className="col-lg-5">
              <div className="hero-card p-4">
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <strong><i className="bi bi-broadcast me-2"></i>Live Air Quality</strong>
                  <span className="small opacity-75">Demo sensors</span>
                </div>
                {readings.length === 0 && <div className="opacity-75">Loading readings...</div>}
                {readings.map((r) => (
                  <div key={r.city} className="d-flex justify-content-between align-items-center py-2 border-bottom border-light border-opacity-25">
                    <span>{r.city}</span>
                    <span>
                      <strong className="me-2">{r.aqi}</strong>
                      <span className="aqi-badge" style={{ background: r.category.color }}>{r.category.label}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container py-5">
        <div className="text-center mb-5">
          <h2 className="fw-bold">Everything you need for a greener tomorrow</h2>
          <p className="text-muted">Eight smart modules working together.</p>
        </div>
        <div className="row g-4">
          {FEATURES.map(([icon, title, text]) => (
            <div className="col-md-6 col-lg-4" key={title}>
              <div className="feature-card p-4">
                <div className="feature-icon mb-3"><i className={`bi bi-${icon}`}></i></div>
                <h5 className="fw-semibold">{title}</h5>
                <p className="text-muted mb-0">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="container">
        <div className="eco-card p-5 text-center" style={{ background: "var(--eco-primary-light)" }}>
          <h3 className="fw-bold">Be part of the solution</h3>
          <p className="text-muted">Create a free account, report an issue in your neighbourhood and get AI recommendations today.</p>
          <Link to={user ? "/reports" : "/register"} className="btn btn-primary btn-lg">
            {user ? "Report a problem" : "Create free account"}
          </Link>
        </div>
      </section>
    </>
  );
}
