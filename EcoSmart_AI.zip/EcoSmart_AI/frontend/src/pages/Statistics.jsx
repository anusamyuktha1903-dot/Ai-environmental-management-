import { useState } from "react";
import { Bar, Doughnut, Line } from "react-chartjs-2";
import { api } from "../services/api";
import { useFetch } from "../services/hooks";
import { PALETTE, aqiColor } from "../services/chartSetup";
import { Alert, Card, PageHeader, Spinner, StatCard } from "../components/UI";

export default function Statistics() {
  const { data, loading, error } = useFetch("/api/stats/overview");
  const [dlError, setDlError] = useState("");

  async function download() {
    setDlError("");
    try {
      await api.download("/api/stats/download", "ecosmart_report.csv");
    } catch (e) {
      setDlError(e.message);
    }
  }

  if (loading) return <Spinner text="Loading statistics..." />;
  if (error) return <Alert>{error}</Alert>;

  const t = data.totals;
  const trend = data.pollution_trend;
  const noLegend = { legend: { display: false } };

  return (
    <>
      <PageHeader title="Environmental Statistics" subtitle="Pollution trends, waste statistics and report summaries from the database">
        <button className="btn btn-primary" onClick={download}><i className="bi bi-download me-1"></i>Download report (CSV)</button>
      </PageHeader>
      <Alert onClose={() => setDlError("")}>{dlError}</Alert>

      <div className="row g-3 mb-4">
        <div className="col-6 col-xl-3"><StatCard icon="flag" label="Environmental reports" value={t.reports} /></div>
        <div className="col-6 col-xl-3"><StatCard icon="check2-circle" label="Resolved reports" value={t.resolved} color="#2e9e5b" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="droplet-half" label="Water reports" value={t.water_reports} color="#0288d1" bg="#e1f3fc" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="recycle" label="Waste reported (kg)" value={t.waste_kg} color="#ef6c00" bg="#fff1e0" /></div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-lg-8">
          <Card title="Pollution trend (average AQI, PM2.5, PM10)">
            <div className="chart-box">
              <Line
                data={{ labels: trend.map((d) => d.day.slice(5)), datasets: [
                  { label: "AQI", data: trend.map((d) => d.avg_aqi), borderColor: "#1f8a4c", backgroundColor: "rgba(31,138,76,.1)", fill: true, tension: 0.35 },
                  { label: "PM2.5", data: trend.map((d) => d.avg_pm25), borderColor: "#f4b400", tension: 0.35 },
                  { label: "PM10", data: trend.map((d) => d.avg_pm10), borderColor: "#8d6e63", tension: 0.35 },
                ] }}
                options={{ maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }}
              />
            </div>
          </Card>
        </div>
        <div className="col-lg-4">
          <Card title="Average AQI by city">
            <div className="chart-box">
              <Bar
                data={{ labels: data.city_aqi.map((c) => c.city), datasets: [{ data: data.city_aqi.map((c) => c.avg_aqi), backgroundColor: data.city_aqi.map((c) => aqiColor(c.avg_aqi)), borderRadius: 6 }] }}
                options={{ maintainAspectRatio: false, plugins: noLegend }}
              />
            </div>
          </Card>
        </div>
      </div>

      <div className="row g-3">
        <div className="col-lg-4">
          <Card title="Waste management (kg by type)">
            <div className="chart-box-sm">
              <Doughnut data={{ labels: data.waste_by_type.map((w) => w.waste_type), datasets: [{ data: data.waste_by_type.map((w) => w.total_kg), backgroundColor: PALETTE }] }}
                        options={{ maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }} />
            </div>
          </Card>
        </div>
        <div className="col-lg-4">
          <Card title="Reports by category">
            <div className="chart-box-sm">
              <Bar data={{ labels: data.reports_by_category.map((c) => c.category), datasets: [{ data: data.reports_by_category.map((c) => c.count), backgroundColor: "#1f8a4c", borderRadius: 6 }] }}
                   options={{ indexAxis: "y", maintainAspectRatio: false, plugins: noLegend, scales: { x: { ticks: { precision: 0 } } } }} />
            </div>
          </Card>
        </div>
        <div className="col-lg-4">
          <Card title="Report status">
            <div className="chart-box-sm">
              <Doughnut data={{ labels: data.reports_by_status.map((s) => s.status), datasets: [{ data: data.reports_by_status.map((s) => s.count), backgroundColor: ["#f4b400", "#26a69a", "#1f8a4c", "#e53935"] }] }}
                        options={{ maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }} />
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
