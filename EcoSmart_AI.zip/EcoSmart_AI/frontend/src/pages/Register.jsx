import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../services/AuthContext";
import { Alert } from "../components/UI";

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState("user");
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "", phone: "", city: "", admin_code: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to={user.role === "admin" ? "/admin" : "/dashboard"} replace />;

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError("");
    // Client-side validation (the server validates again)
    if (form.name.trim().length < 2) return setError("Please enter your full name.");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) return setError("Please enter a valid email address.");
    if (form.password.length < 6) return setError("Password must be at least 6 characters.");
    if (form.password !== form.confirm) return setError("Passwords do not match.");
    if (role === "admin" && !form.admin_code) return setError("Admin registration code is required.");

    setBusy(true);
    try {
      const { confirm, ...payload } = form;
      const u = await register({ ...payload, role });
      navigate(u.role === "admin" ? "/admin" : "/dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-side">
        <Link to="/" className="text-white text-decoration-none fs-4 fw-bold mb-4">
          <i className="bi bi-tree-fill me-2"></i>EcoSmart AI
        </Link>
        <h1 className="fw-bold">Join the green movement</h1>
        <p className="fs-5 opacity-75">Create your account to report problems, track pollution and receive personalised eco tips.</p>
      </div>
      <div className="auth-form">
        <div className="auth-card">
          <h3 className="fw-bold mb-1">Create account</h3>
          <p className="text-muted mb-3">It only takes a minute.</p>

          <div className="btn-group w-100 mb-3" role="group">
            <button type="button" className={`btn ${role === "user" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setRole("user")}>
              <i className="bi bi-person me-1"></i>User
            </button>
            <button type="button" className={`btn ${role === "admin" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setRole("admin")}>
              <i className="bi bi-shield-lock me-1"></i>Admin
            </button>
          </div>

          <Alert onClose={() => setError("")}>{error}</Alert>

          <form onSubmit={submit} noValidate>
            <div className="mb-3">
              <label className="form-label">Full name</label>
              <input className="form-control" name="name" value={form.name} onChange={change} />
            </div>
            <div className="mb-3">
              <label className="form-label">Email</label>
              <input className="form-control" type="email" name="email" value={form.email} onChange={change} autoComplete="username" />
            </div>
            <div className="row g-3 mb-3">
              <div className="col-sm-6">
                <label className="form-label">Password</label>
                <input className="form-control" type="password" name="password" value={form.password} onChange={change} autoComplete="new-password" />
              </div>
              <div className="col-sm-6">
                <label className="form-label">Confirm password</label>
                <input className="form-control" type="password" name="confirm" value={form.confirm} onChange={change} autoComplete="new-password" />
              </div>
            </div>
            {role === "user" ? (
              <div className="row g-3 mb-3">
                <div className="col-sm-6">
                  <label className="form-label">Phone <span className="text-muted">(optional)</span></label>
                  <input className="form-control" name="phone" value={form.phone} onChange={change} />
                </div>
                <div className="col-sm-6">
                  <label className="form-label">City <span className="text-muted">(optional)</span></label>
                  <input className="form-control" name="city" value={form.city} onChange={change} />
                </div>
              </div>
            ) : (
              <div className="mb-3">
                <label className="form-label">Admin registration code</label>
                <input className="form-control" name="admin_code" value={form.admin_code} onChange={change} />
                <div className="form-text">Demo code: ECOADMIN2026 (set in backend/.env)</div>
              </div>
            )}
            <button className="btn btn-primary btn-lg w-100" disabled={busy}>
              {busy ? "Creating account..." : "Register"}
            </button>
          </form>
          <p className="text-center text-muted mt-3 mb-0">
            Already have an account? <Link to="/login">Login</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
