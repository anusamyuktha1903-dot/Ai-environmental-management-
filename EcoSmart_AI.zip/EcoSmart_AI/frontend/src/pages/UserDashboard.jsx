import { Link } from "react-router-dom";
import { Bar, Doughnut } from "react-chartjs-2";
import { useAuth } from "../services/AuthContext";
import { useFetch } from "../services/hooks";
import { PALETTE, aqiColor } from "../services/chartSetup";
import { Card, EmptyState, PageHeader, Spinner, StatCard, StatusBadge, fmtDate } from "../components/UI";

export default function UserDashboard() {
  const { user } = useAuth();
  const reports = useFetch("/api/reports");
  const water = useFetch("/api/water");
  const waste = useFetch("/api/waste/stats");
  const complaints = useFetch("/api/complaints");
  const air = useFetch("/api/air/current");

  if (reports.loading || water.loading || waste.loading || complaints.loading || air.loading) {
    return <Spinner text="Loading your dashboard..." />;
  }

  const myReports = reports.data?.reports || [];
  const byType = waste.data?.by_type || [];
  const totalKg = byType.reduce((s, r) => s + (r.total_kg || 0), 0).toFixed(1);
  const readings = air.data?.readings || [];
  const myCity = readings.find((r) => r.city === user.city) || readings[0];
  const openComplaints = (complaints.data?.complaints || []).filter((c) => c.status === "Open" || c.status === "In Progress").length;

  return (
    <>
      <PageHeader title="My Dashboard" subtitle="Your environmental activity at a glance">
        <Link to="/reports" className="btn btn-primary"><i className="bi bi-plus-circle me-1"></i>Report a problem</Link>
      </PageHeader>

      <div className="row g-3 mb-4">
        <div className="col-6 col-xl-3"><StatCard icon="flag" label="My reports" value={myReports.length} /></div>
        <div className="col-6 col-xl-3"><StatCard icon="droplet-half" label="Water reports" value={(water.data?.reports || []).length} color="#0288d1" bg="#e1f3fc" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="recycle" label="Waste reported (kg)" value={totalKg} color="#ef6c00" bg="#fff1e0" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="envelope-exclamation" label="Open complaints" value={openComplaints} color="#8e24aa" bg="#f4e6f8" /></div>
      </div>

      <div className="row g-3 mb-4">
        <div className="col-lg-4">
          <Card title={<><i className="bi bi-wind me-2 text-primary"></i>Air quality{myCity ? ` - ${myCity.city}` : ""}</>}>
            {myCity ? (
              <div className="text-center">
                <div className="aqi-big" style={{ color: myCity.category.color }}>{myCity.aqi}</div>
                <div className="mt-2"><span className="aqi-badge" style={{ background: myCity.category.color }}>{myCity.category.label}</span></div>
                <div className="text-muted mt-3">PM2.5: <strong>{myCity.pm25}</strong> | PM10: <strong>{myCity.pm10}</strong> ug/m3</div>
                <Link to="/air-quality" className="btn btn-outline-primary btn-sm mt-3">View details</Link>
              </div>
            ) : <EmptyState icon="wind" text="No air data yet" />}
          </Card>
        </div>
        <div className="col-lg-4">
          <Card title="My waste by type (kg)">
            {byType.length ? (
              <div className="chart-box-sm">
                <Doughnut
                  data={{ labels: byType.map((r) => r.waste_type), datasets: [{ data: byType.map((r) => r.total_kg), backgroundColor: PALETTE }] }}
                  options={{ maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }}
                />
              </div>
            ) : <EmptyState icon="recycle" text="No waste reports yet" />}
          </Card>
        </div>
        <div className="col-lg-4">
          <Card title="AQI across cities">
            <div className="chart-box-sm">
              <Bar
                data={{ labels: readings.map((r) => r.city), datasets: [{ label: "AQI", data: readings.map((r) => r.aqi), backgroundColor: readings.map((r) => aqiColor(r.aqi)), borderRadius: 6 }] }}
                options={{ maintainAspectRatio: false, plugins: { legend: { display: false } } }}
              />
            </div>
          </Card>
        </div>
      </div>

      <Card title="Recent reports" right={<Link to="/reports" className="small">View all</Link>} pad={false}>
        {myReports.length === 0 ? (
          <EmptyState icon="flag" text="You have not submitted any reports yet." />
        ) : (
          <div className="table-responsive">
            <table className="table table-eco table-hover mb-0">
              <thead><tr><th>Title</th><th>Category</th><th>Location</th><th>Status</th><th>Date</th></tr></thead>
              <tbody>
                {myReports.slice(0, 5).map((r) => (
                  <tr key={r.id}>
                    <td>{r.title}</td><td>{r.category}</td><td>{r.location}</td>
                    <td><StatusBadge status={r.status} /></td><td className="text-muted">{fmtDate(r.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
