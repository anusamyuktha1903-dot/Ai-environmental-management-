import { useEffect, useState } from "react";
import { Bar, Line } from "react-chartjs-2";
import { api } from "../services/api";
import { useFetch } from "../services/hooks";
import { aqiColor } from "../services/chartSetup";
import { AiBadge, Alert, Card, PageHeader, Spinner } from "../components/UI";

const SCALE = [
  ["0-50", "Good", "#2e9e5b"], ["51-100", "Satisfactory", "#8bc34a"], ["101-200", "Moderate", "#f4b400"],
  ["201-300", "Poor", "#f57c00"], ["301-400", "Very Poor", "#e53935"], ["401+", "Severe", "#8e24aa"],
];

export default function AirQuality() {
  const current = useFetch("/api/air/current");
  const [city, setCity] = useState("Chennai");
  const history = useFetch(`/api/air/history?city=${encodeURIComponent(city)}`);
  const [advice, setAdvice] = useState(null);
  const [adviceBusy, setAdviceBusy] = useState(false);
  const [error, setError] = useState("");

  // Clear the advice when another city is selected
  useEffect(() => setAdvice(null), [city]);

  const readings = current.data?.readings || [];
  const selected = readings.find((r) => r.city === city);
  const hist = history.data?.history || [];
  const labels = hist.map((h) => h.recorded_at.slice(5, 10));

  async function getAdvice() {
    setAdviceBusy(true);
    setError("");
    try {
      setAdvice(await api.get(`/api/air/advice?city=${encodeURIComponent(city)}`));
    } catch (e) {
      setError(e.message);
    } finally {
      setAdviceBusy(false);
    }
  }

  async function simulate() {
    setError("");
    try {
      await api.post("/api/air/simulate", { city });
      current.reload();
      history.reload();
      setAdvice(null);
    } catch (e) {
      setError(e.message);
    }
  }

  if (current.loading) return <Spinner text="Loading air quality data..." />;

  return (
    <>
      <PageHeader title="Air Quality Monitoring" subtitle="AQI, PM2.5 and PM10 readings (demo sensor data)">
        <button className="btn btn-outline-primary" onClick={simulate}><i className="bi bi-broadcast me-1"></i>Simulate new reading</button>
      </PageHeader>
      <Alert>{current.error}</Alert>
      <Alert onClose={() => setError("")}>{error}</Alert>

      <div className="row g-2 mb-4">
        {readings.map((r) => (
          <div className="col-6 col-md-4 col-xl" key={r.city}>
            <div className={`city-pill ${city === r.city ? "active" : ""}`} onClick={() => setCity(r.city)} role="button">
              <div className="fw-semibold">{r.city}</div>
              <div className="d-flex align-items-center justify-content-between">
                <span className="fs-4 fw-bold" style={{ color: r.category.color }}>{r.aqi}</span>
                <span className="small text-muted">{r.category.label}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-3 mb-3">
        <div className="col-lg-4">
          <Card title={`Current air quality - ${city}`}>
            {selected && (
              <div className="text-center">
                <div className="aqi-big" style={{ color: selected.category.color }}>{selected.aqi}</div>
                <div className="mt-2"><span className="aqi-badge" style={{ background: selected.category.color }}>{selected.category.label}</span></div>
                <div className="row mt-4 g-2 text-center">
                  <div className="col-6"><div className="stat-label">PM2.5</div><div className="fs-5 fw-semibold">{selected.pm25} <small className="text-muted">ug/m3</small></div></div>
                  <div className="col-6"><div className="stat-label">PM10</div><div className="fs-5 fw-semibold">{selected.pm10} <small className="text-muted">ug/m3</small></div></div>
                  <div className="col-4"><div className="stat-label">NO2</div><div className="fw-semibold">{selected.no2}</div></div>
                  <div className="col-4"><div className="stat-label">SO2</div><div className="fw-semibold">{selected.so2}</div></div>
                  <div className="col-4"><div className="stat-label">CO</div><div className="fw-semibold">{selected.co}</div></div>
                </div>
                <div className="small text-muted mt-3">Updated {selected.recorded_at.slice(0, 16)}</div>
              </div>
            )}
          </Card>
        </div>
        <div className="col-lg-8">
          <Card title={`AQI trend - ${city}`}>
            {history.loading ? <Spinner /> : (
              <div className="chart-box">
                <Line
                  data={{ labels, datasets: [{ label: "AQI", data: hist.map((h) => h.aqi), borderColor: "#1f8a4c", backgroundColor: "rgba(31,138,76,0.12)", fill: true, tension: 0.35, pointBackgroundColor: hist.map((h) => aqiColor(h.aqi)), pointRadius: 5 }] }}
                  options={{ maintainAspectRatio: false, plugins: { legend: { display: false } } }}
                />
              </div>
            )}
          </Card>
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-lg-7">
          <Card title="PM2.5 and PM10 levels">
            <div className="chart-box-sm">
              <Bar
                data={{ labels, datasets: [
                  { label: "PM2.5", data: hist.map((h) => h.pm25), backgroundColor: "#1f8a4c", borderRadius: 4 },
                  { label: "PM10", data: hist.map((h) => h.pm10), backgroundColor: "#a5d6a7", borderRadius: 4 },
                ] }}
                options={{ maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }}
              />
            </div>
          </Card>
        </div>
        <div className="col-lg-5">
          <Card title="AQI scale">
            {SCALE.map(([range, label, color]) => (
              <div key={label} className="d-flex align-items-center gap-2 mb-2">
                <span style={{ width: 16, height: 16, borderRadius: 4, background: color, display: "inline-block" }}></span>
                <span className="fw-semibold" style={{ width: 100 }}>{label}</span>
                <span className="text-muted">{range}</span>
              </div>
            ))}
          </Card>
        </div>
      </div>

      <Card title="Health & environmental recommendations" right={advice && <AiBadge demo={advice.demo} />}>
        {!advice ? (
          <div className="text-center py-3">
            <p className="text-muted">Get AI-generated advice for the current air quality in {city}.</p>
            <button className="btn btn-primary" onClick={getAdvice} disabled={adviceBusy}>
              {adviceBusy ? "Generating..." : <><i className="bi bi-stars me-1"></i>Get recommendations</>}
            </button>
          </div>
        ) : (
          <div className="ai-output">{advice.advice}</div>
        )}
      </Card>
    </>
  );
}
