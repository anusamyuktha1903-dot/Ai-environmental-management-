import { Link } from "react-router-dom";
import { Bar, Doughnut } from "react-chartjs-2";
import { useFetch } from "../services/hooks";
import { PALETTE, aqiColor } from "../services/chartSetup";
import { Alert, Card, EmptyState, PageHeader, Spinner, StatCard, fmtDate } from "../components/UI";

export default function AdminDashboard() {
  const { data, loading, error, reload } = useFetch("/api/admin/dashboard");

  if (loading) return <Spinner text="Loading admin dashboard..." />;
  if (error) return <Alert>{error}</Alert>;

  const t = data.totals;
  const statuses = data.reports_by_status;
  const cities = data.city_aqi;
  const categories = data.reports_by_category;

  return (
    <>
      <PageHeader title="Admin Dashboard" subtitle="Live statistics from the database">
        <button className="btn btn-outline-primary" onClick={reload}><i className="bi bi-arrow-clockwise me-1"></i>Refresh</button>
        <Link to="/reports" className="btn btn-primary"><i className="bi bi-flag me-1"></i>Review reports</Link>
      </PageHeader>

      <div className="row g-3 mb-4">
        <div className="col-6 col-xl-3"><StatCard icon="people" label="Total users" value={t.users} /></div>
        <div className="col-6 col-xl-3"><StatCard icon="flag" label="Environmental reports" value={t.reports} color="#0288d1" bg="#e1f3fc" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="hourglass-split" label="Pending reports" value={t.pending_reports} color="#f57c00" bg="#fff1e0" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="envelope-exclamation" label="Open complaints" value={t.open_complaints} color="#8e24aa" bg="#f4e6f8" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="wind" label="Avg AQI (3 days)" value={t.avg_aqi ?? "-"} color={aqiColor(t.avg_aqi || 0)} bg="#f1f5f2" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="droplet-half" label="Water reports" value={t.water_reports} color="#0288d1" bg="#e1f3fc" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="recycle" label="Waste reported (kg)" value={t.waste_kg} color="#ef6c00" bg="#fff1e0" /></div>
        <div className="col-6 col-xl-3"><StatCard icon="check2-circle" label="Resolved reports" value={statuses.find((s) => s.status === "Resolved")?.count || 0} /></div>
      </div>

      <div className="row g-3 mb-4">
        <div className="col-lg-4">
          <Card title="Reports by status">
            <div className="chart-box-sm">
              <Doughnut
                data={{ labels: statuses.map((s) => s.status), datasets: [{ data: statuses.map((s) => s.count), backgroundColor: PALETTE }] }}
                options={{ maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }}
              />
            </div>
          </Card>
        </div>
        <div className="col-lg-4">
          <Card title="Pollution: average AQI by city">
            <div className="chart-box-sm">
              <Bar
                data={{ labels: cities.map((c) => c.city), datasets: [{ label: "Avg AQI", data: cities.map((c) => c.avg_aqi), backgroundColor: cities.map((c) => aqiColor(c.avg_aqi)), borderRadius: 6 }] }}
                options={{ maintainAspectRatio: false, plugins: { legend: { display: false } } }}
              />
            </div>
          </Card>
        </div>
        <div className="col-lg-4">
          <Card title="Reports by category">
            <div className="chart-box-sm">
              <Bar
                data={{ labels: categories.map((c) => c.category), datasets: [{ label: "Reports", data: categories.map((c) => c.count), backgroundColor: "#1f8a4c", borderRadius: 6 }] }}
                options={{ indexAxis: "y", maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { ticks: { precision: 0 } } } }}
              />
            </div>
          </Card>
        </div>
      </div>

      <div className="row g-3">
        <div className="col-lg-7">
          <Card title="Environmental activities" right={<span className="small text-muted">Latest 8</span>}>
            {data.recent_activity.length === 0 ? <EmptyState icon="activity" text="No activity yet" /> :
              data.recent_activity.map((a) => (
                <div className="activity-item d-flex justify-content-between gap-3" key={a.id}>
                  <div><strong>{a.actor}</strong> {a.action}</div>
                  <div className="text-muted small text-nowrap">{fmtDate(a.created_at)}</div>
                </div>
              ))}
          </Card>
        </div>
        <div className="col-lg-5">
          <Card title="Quick actions">
            <div className="d-grid gap-2">
              <Link to="/admin/complaints" className="btn btn-outline-primary text-start"><i className="bi bi-envelope-exclamation me-2"></i>Manage user complaints</Link>
              <Link to="/admin/users" className="btn btn-outline-primary text-start"><i className="bi bi-people me-2"></i>Manage users</Link>
              <Link to="/reports" className="btn btn-outline-primary text-start"><i className="bi bi-flag me-2"></i>Review environmental reports</Link>
              <Link to="/statistics" className="btn btn-outline-primary text-start"><i className="bi bi-bar-chart-line me-2"></i>View statistics & download report</Link>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
