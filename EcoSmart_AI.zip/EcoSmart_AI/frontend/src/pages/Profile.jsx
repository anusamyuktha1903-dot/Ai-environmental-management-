import { useState } from "react";
import { api } from "../services/api";
import { useAuth } from "../services/AuthContext";
import { Alert, Card, PageHeader, fmtDate } from "../components/UI";

export default function Profile() {
  const { user, setUser } = useAuth();
  const isAdmin = user.role === "admin";
  const [form, setForm] = useState({
    name: user.name, phone: user.phone || "", city: user.city || "",
    current_password: "", new_password: "",
  });
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [busy, setBusy] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function save(e) {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (form.name.trim().length < 2) return setMsg({ type: "danger", text: "Name must be at least 2 characters." });
    if (form.new_password && form.new_password.length < 6) return setMsg({ type: "danger", text: "New password must be at least 6 characters." });
    if (form.new_password && !form.current_password) return setMsg({ type: "danger", text: "Enter your current password to change it." });

    setBusy(true);
    try {
      const d = await api.put("/api/auth/me", form);
      setUser(d.user);
      setForm({ ...form, current_password: "", new_password: "" });
      setMsg({ type: "success", text: "Profile updated." });
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHeader title="My Profile" subtitle="Manage your account details" />
      <div className="row g-3">
        <div className="col-lg-4">
          <Card>
            <div className="text-center">
              <div className="stat-icon mx-auto mb-3" style={{ width: 84, height: 84, fontSize: "2.4rem", background: "#e8f5ec", color: "#1f8a4c", borderRadius: "50%" }}>
                <i className="bi bi-person"></i>
              </div>
              <h5 className="mb-0">{user.name}</h5>
              <div className="text-muted">{user.email}</div>
              <span className="badge bg-success mt-2 text-capitalize">{user.role}</span>
              <div className="small text-muted mt-3">Member since {fmtDate(user.created_at)}</div>
            </div>
          </Card>
        </div>
        <div className="col-lg-8">
          <Card title="Edit profile">
            <Alert type={msg.type || "info"} onClose={() => setMsg({ type: "", text: "" })}>{msg.text}</Alert>
            <form onSubmit={save} noValidate>
              <div className="row g-3">
                <div className="col-md-6"><label className="form-label">Full name</label><input className="form-control" name="name" value={form.name} onChange={change} /></div>
                <div className="col-md-6"><label className="form-label">Email</label><input className="form-control" value={user.email} disabled /></div>
                {!isAdmin && (
                  <>
                    <div className="col-md-6"><label className="form-label">Phone</label><input className="form-control" name="phone" value={form.phone} onChange={change} /></div>
                    <div className="col-md-6"><label className="form-label">City</label><input className="form-control" name="city" value={form.city} onChange={change} /></div>
                  </>
                )}
                <div className="col-12"><hr className="my-1" /><div className="text-muted small">Change password (optional)</div></div>
                <div className="col-md-6"><label className="form-label">Current password</label><input className="form-control" type="password" name="current_password" value={form.current_password} onChange={change} autoComplete="current-password" /></div>
                <div className="col-md-6"><label className="form-label">New password</label><input className="form-control" type="password" name="new_password" value={form.new_password} onChange={change} autoComplete="new-password" /></div>
              </div>
              <button className="btn btn-primary mt-3" disabled={busy}>{busy ? "Saving..." : "Save changes"}</button>
            </form>
          </Card>
        </div>
      </div>
    </>
  );
}
