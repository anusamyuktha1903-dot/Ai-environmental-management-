import { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../services/api";
import { useFetch } from "../services/hooks";
import { AiBadge, Alert, Card, PageHeader } from "../components/UI";

const SEVERITY_COLOR = { Low: "success", Medium: "warning", High: "danger", Critical: "dark" };

export default function AIAnalysis() {
  const meta = useFetch("/api/reports/categories");
  const [form, setForm] = useState({ category: "", location: "", description: "" });
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function analyze(e) {
    e.preventDefault();
    setError("");
    if (form.description.trim().length < 10) return setError("Please describe the problem in at least 10 characters.");
    setBusy(true);
    setResult(null);
    try {
      const d = await api.post("/api/ai/analyze", form);
      setResult(d.analysis);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Save the generated AI report as a text file in the browser
  function downloadReport() {
    const blob = new Blob([result.report], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "ecosmart_ai_analysis.txt";
    link.click();
    URL.revokeObjectURL(link.href);
  }

  return (
    <>
      <PageHeader title="AI Environmental Analysis" subtitle="Describe an environmental problem and let AI identify the issue and suggest solutions" />
      <div className="row g-3">
        <div className="col-lg-5">
          <Card title="Describe the problem">
            <Alert onClose={() => setError("")}>{error}</Alert>
            <form onSubmit={analyze} noValidate>
              <div className="mb-3">
                <label className="form-label">Category <span className="text-muted">(optional)</span></label>
                <select className="form-select" name="category" value={form.category} onChange={change}>
                  <option value="">Not sure / auto-detect</option>
                  {(meta.data?.categories || []).map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="mb-3">
                <label className="form-label">Location <span className="text-muted">(optional)</span></label>
                <input className="form-control" name="location" value={form.location} onChange={change} placeholder="e.g. Adyar, Chennai" />
              </div>
              <div className="mb-3">
                <label className="form-label">Description</label>
                <textarea className="form-control" rows="6" name="description" value={form.description} onChange={change}
                          placeholder="e.g. Thick black smoke comes out of a factory chimney every evening and people are coughing..." />
              </div>
              <button className="btn btn-primary w-100" disabled={busy}>
                {busy ? <><span className="spinner-border spinner-border-sm me-2"></span>Analysing...</> : <><i className="bi bi-cpu me-1"></i>Analyse with AI</>}
              </button>
            </form>
          </Card>
        </div>

        <div className="col-lg-7">
          {!result && !busy && (
            <Card><div className="text-center text-muted py-5"><i className="bi bi-cpu fs-1"></i><div className="mt-2">Your AI analysis will appear here.</div></div></Card>
          )}
          {busy && <Card><div className="text-center py-5"><div className="spinner-border text-primary"></div><div className="mt-2 text-muted">AI is analysing your report...</div></div></Card>}
          {result && (
            <Card title="Analysis result" right={<AiBadge demo={result.demo} />}>
              <div className="d-flex flex-wrap gap-2 align-items-center mb-3">
                <span className="badge bg-primary fs-6">{result.issue_type}</span>
                <span className={`badge bg-${SEVERITY_COLOR[result.severity] || "secondary"} fs-6`}>Severity: {result.severity}</span>
              </div>
              <p>{result.summary}</p>

              <h6 className="fw-semibold mt-3">Possible causes</h6>
              <ul>{(result.causes || []).map((c, i) => <li key={i}>{c}</li>)}</ul>

              <h6 className="fw-semibold">Health & environmental impact</h6>
              <p>{result.health_impact}</p>

              <h6 className="fw-semibold">Recommended solutions</h6>
              <ol>{(result.suggestions || []).map((s, i) => <li key={i}>{s}</li>)}</ol>

              <h6 className="fw-semibold mt-3">Generated report</h6>
              <div className="ai-output">{result.report}</div>

              <div className="d-flex flex-wrap gap-2 mt-3">
                <button className="btn btn-outline-primary" onClick={downloadReport}><i className="bi bi-download me-1"></i>Download report</button>
                <Link to="/reports" className="btn btn-primary"><i className="bi bi-flag me-1"></i>Submit as official report</Link>
              </div>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
