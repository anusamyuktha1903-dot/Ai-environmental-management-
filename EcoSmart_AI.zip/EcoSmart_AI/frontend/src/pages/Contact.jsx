import { useState } from "react";
import { api } from "../services/api";
import { Alert } from "../components/UI";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [busy, setBusy] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setMsg({ type: "", text: "" });
    try {
      const d = await api.post("/api/contact", form);
      setMsg({ type: "success", text: d.message });
      setForm({ name: "", email: "", message: "" });
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container py-5">
      <div className="row g-5">
        <div className="col-lg-5">
          <h1 className="fw-bold">Contact <span className="text-primary">Us</span></h1>
          <p className="text-muted">Questions, feedback or ideas to make the project greener? Send us a message.</p>
          <div className="eco-card card-pad">
            <p className="mb-2"><i className="bi bi-geo-alt text-primary me-2"></i>College Campus, India</p>
            <p className="mb-2"><i className="bi bi-envelope text-primary me-2"></i>support@ecosmart.com</p>
            <p className="mb-0"><i className="bi bi-clock text-primary me-2"></i>Mon - Fri, 9:00 AM - 5:00 PM</p>
          </div>
        </div>
        <div className="col-lg-7">
          <form className="eco-card card-pad" onSubmit={submit} noValidate>
            <Alert type={msg.type || "info"} onClose={() => setMsg({ type: "", text: "" })}>{msg.text}</Alert>
            <div className="mb-3">
              <label className="form-label">Your name</label>
              <input className="form-control" name="name" value={form.name} onChange={change} required />
            </div>
            <div className="mb-3">
              <label className="form-label">Email</label>
              <input className="form-control" type="email" name="email" value={form.email} onChange={change} required />
            </div>
            <div className="mb-3">
              <label className="form-label">Message</label>
              <textarea className="form-control" rows="5" name="message" value={form.message} onChange={change} required />
            </div>
            <button className="btn btn-primary" disabled={busy}>
              {busy ? "Sending..." : <><i className="bi bi-send me-1"></i>Send message</>}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
