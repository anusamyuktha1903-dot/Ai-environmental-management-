import { useState } from "react";
import { api } from "../services/api";
import { useAuth } from "../services/AuthContext";
import { useFetch } from "../services/hooks";
import { Alert, Card, EmptyState, PageHeader, Spinner, StatusBadge, fmtDate } from "../components/UI";

const EMPTY = { location: "", source_type: "River", ph: "", turbidity: "", tds: "", dissolved_oxygen: "", description: "" };

export default function Water() {
  const { user } = useAuth();
  const isAdmin = user.role === "admin";
  const meta = useFetch("/api/water/meta");
  const list = useFetch("/api/water");
  const [form, setForm] = useState(EMPTY);
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [issues, setIssues] = useState(null);
  const [busy, setBusy] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    setIssues(null);
    if (form.location.trim().length < 3) return setMsg({ type: "danger", text: "Please enter the location." });
    setBusy(true);
    try {
      const d = await api.post("/api/water", form);
      setIssues(d.issues);
      setMsg({ type: "success", text: "Water quality report submitted." });
      setForm(EMPTY);
      list.reload();
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function setStatus(id, status) {
    try {
      await api.put(`/api/water/${id}`, { status });
      list.reload();
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    }
  }

  const reports = list.data?.reports || [];

  return (
    <>
      <PageHeader title={isAdmin ? "Water Quality Reports" : "Water Quality Management"}
                  subtitle="Record water quality, detect possible pollution issues and learn to conserve water" />
      <Alert type={msg.type || "info"} onClose={() => setMsg({ type: "", text: "" })}>{msg.text}</Alert>

      <div className="row g-3 mb-3">
        {!isAdmin && (
          <div className="col-lg-5">
            <Card title="Submit water quality report">
              <form onSubmit={submit} noValidate>
                <div className="row g-3">
                  <div className="col-sm-7">
                    <label className="form-label">Location</label>
                    <input className="form-control" name="location" value={form.location} onChange={change} placeholder="e.g. Adyar River bridge" />
                  </div>
                  <div className="col-sm-5">
                    <label className="form-label">Source</label>
                    <select className="form-select" name="source_type" value={form.source_type} onChange={change}>
                      {(meta.data?.sources || ["River"]).map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                  <div className="col-6"><label className="form-label">pH <span className="text-muted">(0-14)</span></label><input className="form-control" type="number" step="0.1" name="ph" value={form.ph} onChange={change} /></div>
                  <div className="col-6"><label className="form-label">Turbidity <span className="text-muted">(NTU)</span></label><input className="form-control" type="number" step="0.1" name="turbidity" value={form.turbidity} onChange={change} /></div>
                  <div className="col-6"><label className="form-label">TDS <span className="text-muted">(mg/L)</span></label><input className="form-control" type="number" step="1" name="tds" value={form.tds} onChange={change} /></div>
                  <div className="col-6"><label className="form-label">Dissolved oxygen <span className="text-muted">(mg/L)</span></label><input className="form-control" type="number" step="0.1" name="dissolved_oxygen" value={form.dissolved_oxygen} onChange={change} /></div>
                  <div className="col-12"><label className="form-label">Observations</label><textarea className="form-control" rows="3" name="description" value={form.description} onChange={change} placeholder="Colour, smell, floating waste, oil..." /></div>
                </div>
                <button className="btn btn-primary w-100 mt-3" disabled={busy}>{busy ? "Submitting..." : "Submit report"}</button>
              </form>
              {issues && (
                <div className={`alert mt-3 mb-0 ${issues.length ? "alert-warning" : "alert-success"}`}>
                  <strong>{issues.length ? "Possible issues detected:" : "No major issues detected."}</strong>
                  {issues.length > 0 && <ul className="mb-0">{issues.map((i) => <li key={i}>{i}</li>)}</ul>}
                </div>
              )}
              <div className="small text-muted mt-3">Safe ranges: pH 6.5-8.5, turbidity under 5 NTU, TDS under 500 mg/L, dissolved oxygen above 5 mg/L.</div>
            </Card>
          </div>
        )}

        <div className={isAdmin ? "col-12" : "col-lg-7"}>
          <Card title={isAdmin ? "All water quality reports" : "My water quality reports"} pad={false}>
            {list.loading ? <Spinner /> : reports.length === 0 ? <EmptyState icon="droplet" text="No water reports yet." /> : (
              <div className="table-responsive">
                <table className="table table-eco table-hover mb-0">
                  <thead><tr>{isAdmin && <th>User</th>}<th>Location</th><th>pH</th><th>Turb.</th><th>TDS</th><th>DO</th><th>Issues detected</th><th>Status</th><th>Date</th></tr></thead>
                  <tbody>
                    {reports.map((r) => (
                      <tr key={r.id}>
                        {isAdmin && <td>{r.user_name}</td>}
                        <td>{r.location}<div className="small text-muted">{r.source_type}</div></td>
                        <td>{r.ph ?? "-"}</td><td>{r.turbidity ?? "-"}</td><td>{r.tds ?? "-"}</td><td>{r.dissolved_oxygen ?? "-"}</td>
                        <td style={{ minWidth: 200 }} className="small">{r.issues_detected}</td>
                        <td>
                          {isAdmin ? (
                            <select className="form-select form-select-sm" value={r.status} onChange={(e) => setStatus(r.id, e.target.value)}>
                              {["Pending", "Reviewed", "Action Taken"].map((s) => <option key={s}>{s}</option>)}
                            </select>
                          ) : <StatusBadge status={r.status} />}
                        </td>
                        <td className="text-muted">{fmtDate(r.created_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>

      <h5 className="fw-bold mt-4 mb-3"><i className="bi bi-droplet-half text-primary me-2"></i>Water conservation recommendations</h5>
      <div className="row g-3">
        {(meta.data?.tips || []).map((t) => (
          <div className="col-md-6 col-xl-4" key={t.title}>
            <div className="feature-card p-3">
              <h6 className="fw-semibold text-primary mb-1">{t.title}</h6>
              <div className="text-muted small">{t.tip}</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
