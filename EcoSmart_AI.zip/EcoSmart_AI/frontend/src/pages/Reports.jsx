import { useRef, useState } from "react";
import { api } from "../services/api";
import { useAuth } from "../services/AuthContext";
import { useFetch } from "../services/hooks";
import { Alert, Card, EmptyState, PageHeader, Spinner, StatusBadge, fmtDate } from "../components/UI";

const EMPTY = { title: "", category: "Waste Dumping", location: "", description: "" };

export default function Reports() {
  const { user } = useAuth();
  const isAdmin = user.role === "admin";
  const meta = useFetch("/api/reports/categories");
  const [filter, setFilter] = useState("");
  const list = useFetch(`/api/reports${filter ? `?status=${encodeURIComponent(filter)}` : ""}`);
  const [form, setForm] = useState(EMPTY);
  const [image, setImage] = useState(null);
  const fileRef = useRef(null);
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [busy, setBusy] = useState(false);
  const [review, setReview] = useState(null); // report being reviewed by admin
  const [reviewForm, setReviewForm] = useState({ status: "In Progress", admin_remarks: "" });

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  function pickImage(e) {
    const f = e.target.files[0];
    if (!f) return setImage(null);
    if (f.size > 5 * 1024 * 1024) {
      setMsg({ type: "danger", text: "Image is too large (max 5 MB)." });
      e.target.value = "";
      return setImage(null);
    }
    setImage(f);
  }

  async function submit(e) {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (form.title.trim().length < 4) return setMsg({ type: "danger", text: "Title must be at least 4 characters." });
    if (form.location.trim().length < 3) return setMsg({ type: "danger", text: "Please enter the location." });
    if (form.description.trim().length < 10) return setMsg({ type: "danger", text: "Description must be at least 10 characters." });

    const fd = new FormData();
    Object.entries(form).forEach(([k, v]) => fd.append(k, v));
    if (image) fd.append("image", image);

    setBusy(true);
    try {
      await api.postForm("/api/reports", fd);
      setMsg({ type: "success", text: "Report submitted successfully. You can track its status below." });
      setForm(EMPTY);
      setImage(null);
      if (fileRef.current) fileRef.current.value = "";
      list.reload();
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function remove(r) {
    if (!window.confirm(`Delete report "${r.title}"?`)) return;
    try {
      await api.del(`/api/reports/${r.id}`);
      list.reload();
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    }
  }

  function openReview(r) {
    setReview(r);
    setReviewForm({ status: r.status === "Pending" ? "In Progress" : r.status, admin_remarks: r.admin_remarks || "" });
  }

  async function saveReview() {
    try {
      await api.put(`/api/reports/${review.id}`, reviewForm);
      setMsg({ type: "success", text: "Report updated." });
      setReview(null);
      list.reload();
    } catch (err) {
      setMsg({ type: "danger", text: err.message });
    }
  }

  const reports = list.data?.reports || [];
  const statuses = meta.data?.statuses || [];

  return (
    <>
      <PageHeader title="Environmental Reports"
                  subtitle={isAdmin ? "Review reports submitted by users and update their status" : "Report environmental problems and track their status"} />
      <Alert type={msg.type || "info"} onClose={() => setMsg({ type: "", text: "" })}>{msg.text}</Alert>

      {!isAdmin && (
        <Card title="Report a problem" className="mb-3">
          <form onSubmit={submit} noValidate>
            <div className="row g-3">
              <div className="col-md-6"><label className="form-label">Title</label><input className="form-control" name="title" value={form.title} onChange={change} placeholder="Short summary" /></div>
              <div className="col-md-3">
                <label className="form-label">Category</label>
                <select className="form-select" name="category" value={form.category} onChange={change}>
                  {(meta.data?.categories || []).map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="col-md-3"><label className="form-label">Location</label><input className="form-control" name="location" value={form.location} onChange={change} placeholder="Area, city" /></div>
              <div className="col-md-8"><label className="form-label">Description</label><textarea className="form-control" rows="3" name="description" value={form.description} onChange={change} /></div>
              <div className="col-md-4">
                <label className="form-label">Photo <span className="text-muted">(optional, max 5 MB)</span></label>
                <input className="form-control" type="file" accept="image/png,image/jpeg,image/gif,image/webp" ref={fileRef} onChange={pickImage} />
                {image && <img alt="preview" src={URL.createObjectURL(image)} className="report-img mt-2" style={{ maxHeight: 90 }} />}
              </div>
            </div>
            <button className="btn btn-primary mt-3" disabled={busy}>{busy ? "Submitting..." : <><i className="bi bi-send me-1"></i>Submit report</>}</button>
          </form>
        </Card>
      )}

      {review && (
        <Card title={`Review: ${review.title}`} className="mb-3">
          <p className="text-muted mb-2">{review.description}</p>
          <div className="row g-3">
            <div className="col-md-3">
              <label className="form-label">Status</label>
              <select className="form-select" value={reviewForm.status} onChange={(e) => setReviewForm({ ...reviewForm, status: e.target.value })}>
                {statuses.map((s) => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="col-md-9">
              <label className="form-label">Remarks for the user</label>
              <input className="form-control" maxLength={500} value={reviewForm.admin_remarks} onChange={(e) => setReviewForm({ ...reviewForm, admin_remarks: e.target.value })} />
            </div>
          </div>
          <div className="d-flex gap-2 mt-3">
            <button className="btn btn-primary" onClick={saveReview}>Save</button>
            <button className="btn btn-outline-secondary" onClick={() => setReview(null)}>Cancel</button>
          </div>
        </Card>
      )}

      <div className="d-flex flex-wrap align-items-center gap-2 mb-3">
        <span className="fw-semibold">Filter:</span>
        {["", ...statuses].map((s) => (
          <button key={s || "all"} className={`btn btn-sm ${filter === s ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setFilter(s)}>
            {s || "All"}
          </button>
        ))}
      </div>

      {list.loading ? <Spinner /> : reports.length === 0 ? (
        <Card><EmptyState icon="flag" text="No reports found." /></Card>
      ) : (
        <div className="row g-3">
          {reports.map((r) => (
            <div className="col-md-6 col-xl-4" key={r.id}>
              <div className="eco-card h-100 d-flex flex-column">
                {r.image_path && <img className="report-img" style={{ borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }} src={`/uploads/${r.image_path}`} alt={r.title} />}
                <div className="card-pad flex-grow-1">
                  <div className="d-flex justify-content-between align-items-start gap-2 mb-1">
                    <h6 className="fw-semibold mb-0">{r.title}</h6>
                    <StatusBadge status={r.status} />
                  </div>
                  <div className="small text-muted mb-2"><i className="bi bi-tag me-1"></i>{r.category} <i className="bi bi-geo-alt ms-2 me-1"></i>{r.location}</div>
                  <p className="small mb-2">{r.description}</p>
                  {isAdmin && <div className="small text-muted"><i className="bi bi-person me-1"></i>{r.user_name} ({r.user_email})</div>}
                  {r.admin_remarks && <div className="small text-success mt-2"><i className="bi bi-chat-left-text me-1"></i><strong>Admin:</strong> {r.admin_remarks}</div>}
                </div>
                <div className="px-3 pb-3 d-flex justify-content-between align-items-center">
                  <span className="small text-muted">{fmtDate(r.created_at)}</span>
                  <div className="d-flex gap-1">
                    {isAdmin && <button className="btn btn-outline-primary btn-sm" onClick={() => openReview(r)}>Review</button>}
                    {(isAdmin || r.status === "Pending") && <button className="btn btn-outline-danger btn-sm" onClick={() => remove(r)}><i className="bi bi-trash"></i></button>}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
