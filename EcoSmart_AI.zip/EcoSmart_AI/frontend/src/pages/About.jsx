const TECH = [
  ["React.js + Bootstrap", "Responsive single-page frontend with charts (Chart.js)."],
  ["Python Flask", "REST API with authentication, validation and file uploads."],
  ["SQLite", "Lightweight relational database with demo environmental data."],
  ["Claude AI (Anthropic)", "Environmental analysis, chatbot and recommendations, with a built-in demo mode."],
];

export default function About() {
  return (
    <div className="container py-5">
      <div className="row g-5 align-items-center">
        <div className="col-lg-6">
          <h1 className="fw-bold">About <span className="text-primary">EcoSmart AI</span></h1>
          <p className="text-muted fs-5">
            EcoSmart AI is an AI-Centered Environmental Management System built as a college project.
            It brings monitoring, reporting and intelligent guidance together so that citizens and
            administrators can understand environmental problems and act on them faster.
          </p>
          <p className="text-muted">
            Users can check air quality, submit water-pollution and waste reports, upload photos of
            environmental issues and chat with an AI assistant. Administrators review reports, manage
            complaints and watch live pollution statistics.
          </p>
        </div>
        <div className="col-lg-6">
          <div className="eco-card card-pad">
            <h5 className="fw-semibold mb-3"><i className="bi bi-bullseye text-primary me-2"></i>Our objectives</h5>
            <ul className="mb-0 text-muted">
              <li>Monitor environmental conditions with clear, simple dashboards.</li>
              <li>Identify problems from plain-language descriptions using AI.</li>
              <li>Encourage correct waste segregation and recycling.</li>
              <li>Give personalised tips to cut pollution, water and energy use.</li>
            </ul>
          </div>
        </div>
      </div>

      <h3 className="fw-bold mt-5 mb-4">Technology stack</h3>
      <div className="row g-4">
        {TECH.map(([name, text]) => (
          <div className="col-md-6 col-lg-3" key={name}>
            <div className="feature-card p-4">
              <h6 className="fw-semibold text-primary">{name}</h6>
              <p className="text-muted mb-0 small">{text}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
