// Register the Chart.js parts used across the app (import this once from main.jsx)
import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
} from "chart.js";

ChartJS.register(
  ArcElement, BarElement, CategoryScale, Filler, Legend,
  LinearScale, LineElement, PointElement, Tooltip
);

// Green / nature palette used by all charts
export const PALETTE = ["#1f8a4c", "#5cb85c", "#f4b400", "#26a69a", "#8d6e63", "#4caf50", "#ef6c00", "#78909c"];

export const aqiColor = (aqi) =>
  aqi <= 50 ? "#2e9e5b" : aqi <= 100 ? "#8bc34a" : aqi <= 200 ? "#f4b400"
  : aqi <= 300 ? "#f57c00" : aqi <= 400 ? "#e53935" : "#8e24aa";
