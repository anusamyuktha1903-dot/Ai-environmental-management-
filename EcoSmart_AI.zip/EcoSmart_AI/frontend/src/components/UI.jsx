// Small reusable UI building blocks used by every page.

export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-4">
      <div>
        <h3 className="page-title">{title}</h3>
        {subtitle && <div className="page-sub">{subtitle}</div>}
      </div>
      <div className="d-flex gap-2 flex-wrap">{children}</div>
    </div>
  );
}

export function StatCard({ icon, label, value, color = "#1f8a4c", bg = "#e8f5ec" }) {
  return (
    <div className="eco-card stat-card h-100">
      <div className="stat-icon" style={{ background: bg, color }}>
        <i className={`bi bi-${icon}`}></i>
      </div>
      <div>
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
      </div>
    </div>
  );
}

const STATUS_COLORS = {
  Pending: "warning", "In Progress": "info", Resolved: "success", Rejected: "danger",
  Reported: "warning", Scheduled: "info", Collected: "success",
  Reviewed: "info", "Action Taken": "success",
  Open: "warning", Closed: "secondary",
};

export function StatusBadge({ status }) {
  const color = STATUS_COLORS[status] || "secondary";
  const dark = color === "warning" || color === "info" ? " text-dark" : "";
  return <span className={`badge rounded-pill bg-${color}${dark}`}>{status}</span>;
}

export function Spinner({ text = "Loading..." }) {
  return (
    <div className="text-center text-muted py-5">
      <div className="spinner-border text-primary mb-2" role="status"></div>
      <div>{text}</div>
    </div>
  );
}

export function Alert({ type = "danger", children, onClose }) {
  if (!children) return null;
  return (
    <div className={`alert alert-${type} d-flex justify-content-between align-items-start`} role="alert">
      <div>{children}</div>
      {onClose && <button type="button" className="btn-close" onClick={onClose} aria-label="Close"></button>}
    </div>
  );
}

export function EmptyState({ icon = "inbox", text }) {
  return (
    <div className="text-center text-muted py-5">
      <i className={`bi bi-${icon} fs-1`}></i>
      <div className="mt-2">{text}</div>
    </div>
  );
}

export function Card({ title, right, children, pad = true, className = "" }) {
  return (
    <div className={`eco-card ${className}`}>
      {(title || right) && (
        <div className="card-title-row">
          <span>{title}</span>
          <span>{right}</span>
        </div>
      )}
      <div className={pad ? "card-pad" : ""}>{children}</div>
    </div>
  );
}

export const fmtDate = (s) => (s ? s.replace("T", " ").slice(0, 16) : "");

export function AiBadge({ demo }) {
  return demo ? (
    <span className="demo-pill"><i className="bi bi-lightning-charge"></i> Demo mode</span>
  ) : (
    <span className="live-pill"><i className="bi bi-stars"></i> Claude AI</span>
  );
}
