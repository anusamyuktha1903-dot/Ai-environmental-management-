import { Navigate } from "react-router-dom";
import { useAuth } from "../services/AuthContext";
import { Spinner } from "./UI";

// Redirects to /login when not signed in; optionally restricts a route to one role.
export default function ProtectedRoute({ role, children }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner text="Checking session..." />;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) {
    return <Navigate to={user.role === "admin" ? "/admin" : "/dashboard"} replace />;
  }
  return children;
}
