import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../services/AuthContext";

// Sidebar entries per role: [path, icon, label]
const USER_LINKS = [
  ["/dashboard", "speedometer2", "Dashboard"],
  ["/analysis", "cpu", "AI Analysis"],
  ["/air-quality", "wind", "Air Quality"],
  ["/water", "droplet-half", "Water Management"],
  ["/waste", "recycle", "Waste Management"],
  ["/reports", "flag", "Environmental Reports"],
  ["/chatbot", "chat-dots", "AI Chatbot"],
  ["/statistics", "bar-chart-line", "Statistics"],
  ["/recommendations", "lightbulb", "Recommendations"],
  ["/complaints", "envelope-exclamation", "My Complaints"],
  ["/profile", "person-circle", "My Profile"],
];

const ADMIN_LINKS = [
  ["/admin", "speedometer2", "Admin Dashboard"],
  ["/admin/users", "people", "Users"],
  ["/admin/complaints", "envelope-exclamation", "Complaints"],
  ["/reports", "flag", "Environmental Reports"],
  ["/air-quality", "wind", "Air Quality"],
  ["/water", "droplet-half", "Water Reports"],
  ["/waste", "recycle", "Waste Reports"],
  ["/statistics", "bar-chart-line", "Statistics"],
  ["/analysis", "cpu", "AI Analysis"],
  ["/chatbot", "chat-dots", "AI Chatbot"],
  ["/profile", "person-circle", "My Profile"],
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const links = user.role === "admin" ? ADMIN_LINKS : USER_LINKS;

  // Close the mobile sidebar after navigating
  useEffect(() => setOpen(false), [location.pathname]);

  return (
    <div className="app-shell">
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="sidebar-brand">
          <Link to="/" className="text-decoration-none" style={{ color: "inherit" }}>
            <i className="bi bi-tree-fill me-2"></i>EcoSmart AI
          </Link>
        </div>
        <nav className="sidebar-nav nav flex-column">
          <div className="sidebar-section">{user.role === "admin" ? "Administration" : "Menu"}</div>
          {links.map(([to, icon, label]) => (
            <NavLink key={to} to={to} end className="nav-link">
              <i className={`bi bi-${icon}`}></i>
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="small text-muted mb-2">
            <i className="bi bi-person-check me-1"></i>
            {user.name} <span className="badge bg-success ms-1">{user.role}</span>
          </div>
          <button className="btn btn-outline-primary btn-sm w-100" onClick={() => { logout(); navigate("/login"); }}>
            <i className="bi bi-box-arrow-right me-1"></i>Logout
          </button>
        </div>
      </aside>
      <div className={`sidebar-backdrop ${open ? "show" : ""}`} onClick={() => setOpen(false)}></div>

      <div className="main-area">
        <header className="topbar">
          <button className="btn btn-outline-primary btn-sm d-lg-none" onClick={() => setOpen(true)} aria-label="Open menu">
            <i className="bi bi-list fs-5"></i>
          </button>
          <div className="fw-semibold text-muted d-none d-sm-block">
            Welcome back, <span className="text-primary">{user.name}</span>
          </div>
          <div className="ms-auto d-flex gap-2">
            <Link to="/" className="btn btn-light btn-sm"><i className="bi bi-house me-1"></i>Home</Link>
          </div>
        </header>
        <main className="page-body">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
