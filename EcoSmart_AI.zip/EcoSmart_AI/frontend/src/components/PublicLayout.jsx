import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../services/AuthContext";

// Navbar + footer wrapper for the public pages (Home, About, Contact)
export default function PublicLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const dashPath = user?.role === "admin" ? "/admin" : "/dashboard";

  return (
    <>
      <nav className="navbar navbar-expand-lg eco-navbar sticky-top">
        <div className="container">
          <Link className="navbar-brand eco-brand" to="/">
            <i className="bi bi-tree-fill me-2"></i>EcoSmart AI
          </Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#pubNav"
                  aria-controls="pubNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="pubNav">
            <ul className="navbar-nav ms-auto align-items-lg-center gap-lg-1">
              <li className="nav-item"><NavLink end className="nav-link" to="/">Home</NavLink></li>
              <li className="nav-item"><NavLink className="nav-link" to="/about">About Us</NavLink></li>
              <li className="nav-item"><NavLink className="nav-link" to="/contact">Contact</NavLink></li>
              {user ? (
                <>
                  <li className="nav-item ms-lg-2">
                    <button className="btn btn-primary btn-sm" onClick={() => navigate(dashPath)}>
                      <i className="bi bi-speedometer2 me-1"></i>Dashboard
                    </button>
                  </li>
                  <li className="nav-item">
                    <button className="btn btn-outline-primary btn-sm" onClick={() => { logout(); navigate("/"); }}>
                      Logout
                    </button>
                  </li>
                </>
              ) : (
                <>
                  <li className="nav-item ms-lg-2"><Link className="btn btn-outline-primary btn-sm" to="/login">Login</Link></li>
                  <li className="nav-item"><Link className="btn btn-primary btn-sm" to="/register">Register</Link></li>
                </>
              )}
            </ul>
          </div>
        </div>
      </nav>

      <Outlet />

      <footer className="eco-footer py-4 mt-5">
        <div className="container d-flex flex-wrap justify-content-between gap-2">
          <div><i className="bi bi-tree-fill me-2"></i><strong>EcoSmart AI</strong> - AI-Centered Environmental Management System</div>
          <div className="d-flex gap-3">
            <Link to="/about">About</Link>
            <Link to="/contact">Contact</Link>
            <Link to="/login">Login</Link>
          </div>
        </div>
      </footer>
    </>
  );
}
